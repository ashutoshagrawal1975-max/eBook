const mongoose = require("mongoose");


const bookSchema = new mongoose.Schema(
{

    title:{
        type:String,
        required:true,
        trim:true
    },


    author:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Author",
        required:true
    },


    description:{
        type:String,
        default:""
    },


    coverImage:{
        type:String,
        required:true
    },


    genre:{
        type:String,
        required:true
    },


    language:{
        type:String,
        default:"English"
    },


    price:{
        type:Number,
        required:true
    },


    discount:{
        type:Number,
        default:0
    },


    stock:{
        type:Number,
        default:0
    },


    ratings:{
        average:{
            type:Number,
            default:0
        },

        count:{
            type:Number,
            default:0
        }
    },


    featured:{
        type:Boolean,
        default:false
    },


    trending:{
        type:Boolean,
        default:false
    },


    bestSeller:{
        type:Boolean,
        default:false
    },


    pages:{
        type:Number,
        default:0
    },


    publisher:{
        type:String,
        default:""
    }

},
{
    timestamps:true
}
);



module.exports = mongoose.model(
    "Book",
    bookSchema
);