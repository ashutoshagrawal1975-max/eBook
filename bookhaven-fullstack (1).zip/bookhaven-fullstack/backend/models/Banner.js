const mongoose=require("mongoose");

const bannerSchema=new mongoose.Schema({

title:{
type:String,
required:true
},

image:{
type:String,
required:true
},

subtitle:{
type:String,
default:""
},

buttonText:{
type:String,
default:"Shop Now"
},

buttonLink:{
type:String,
default:"/books"
},

active:{
type:Boolean,
default:true
}

},
{
timestamps:true
});

module.exports=mongoose.model("Banner",bannerSchema);