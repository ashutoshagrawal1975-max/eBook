const mongoose = require("mongoose");


const authorSchema = new mongoose.Schema(
{
    name:{
        type:String,
        required:true,
        trim:true
    },


    bio:{
        type:String,
        default:""
    },


    image:{
        type:String,
        default:""
    },


    nationality:{
        type:String,
        default:""
    },


    booksCount:{
        type:Number,
        default:0
    }

},
{
    timestamps:true
}
);


module.exports = mongoose.model(
    "Author",
    authorSchema
);