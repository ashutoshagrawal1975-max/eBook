module.exports = [

{
name:"James Clear",
nationality:"American",
image:"https://images.gr-assets.com/authors/1492591811p8/819789.jpg",
bio:"Author of Atomic Habits"
},

{
name:"Robert T. Kiyosaki",
nationality:"American",
image:"https://images.gr-assets.com/authors/1361975680p8/600.jpg",
bio:"Author of Rich Dad Poor Dad"
},

{
name:"Paulo Coelho",
nationality:"Brazilian",
image:"https://images.gr-assets.com/authors/1206466782p8/566.jpg",
bio:"Author of The Alchemist"
},

{
name:"Morgan Housel",
nationality:"American",
image:"https://images.gr-assets.com/authors/1586433738p8/7499284.jpg",
bio:"Author of Psychology of Money"
},

{
name:"J. K. Rowling",
nationality:"British",
image:"https://images.gr-assets.com/authors/1596216614p8/1077326.jpg",
bio:"Harry Potter Author"
},

{
name:"George Orwell",
nationality:"British",
image:"https://images.gr-assets.com/authors/1532714506p8/3706.jpg",
bio:"1984 Author"
},

{
name:"Stephen King",
nationality:"American",
image:"https://images.gr-assets.com/authors/1362814142p8/3389.jpg",
bio:"Famous Horror Writer"
},

{
name:"Dan Brown",
nationality:"American",
image:"https://images.gr-assets.com/authors/1361214142p8/630.jpg",
bio:"Da Vinci Code Author"
},

{
name:"Chetan Bhagat",
nationality:"Indian",
image:"https://images.gr-assets.com/authors/1265202135p8/3391.jpg",
bio:"Indian Bestselling Author"
},

{
name:"Ruskin Bond",
nationality:"Indian",
image:"https://images.gr-assets.com/authors/1321970032p8/18819.jpg",
bio:"Indian Author"
},

{
name:"Robin Sharma",
nationality:"Canadian",
image:"https://images.gr-assets.com/authors/1405512780p8/24678.jpg",
bio:"Leadership Author"
},

{
name:"Napoleon Hill",
nationality:"American",
image:"https://images.gr-assets.com/authors/1327124694p8/4762.jpg",
bio:"Think and Grow Rich"
},

{
name:"J. R. R. Tolkien",
nationality:"British",
image:"https://images.gr-assets.com/authors/1366732885p8/656983.jpg",
bio:"Lord of the Rings"
},

{
name:"Cal Newport",
nationality:"American",
image:"https://images.gr-assets.com/authors/1361329260p8/147891.jpg",
bio:"Deep Work Author"
},

{
name:"Eric Matthes",
nationality:"American",
image:"https://images.gr-assets.com/authors/1446570604p8/8690077.jpg",
bio:"Python Crash Course"
}

];