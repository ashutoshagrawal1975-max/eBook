module.exports = [

{
title:"Atomic Habits",
genre:"Self Help",
price:499,
discount:20,
stock:40,
featured:true,
trending:true,
description:"Tiny changes, remarkable results.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91bYsX41DVL.jpg"
},

{
title:"Rich Dad Poor Dad",
genre:"Business",
price:399,
discount:15,
stock:30,
featured:true,
trending:true,
description:"Financial education for everyone.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81bsw6fnUiL.jpg"
},

{
title:"The Psychology of Money",
genre:"Business",
price:450,
discount:10,
stock:35,
featured:true,
trending:true,
description:"Timeless lessons on wealth.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71g2ednj0JL.jpg"
},

{
title:"The Alchemist",
genre:"Novel",
price:350,
discount:12,
stock:25,
featured:true,
trending:false,
description:"Follow your dreams.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71aFt4+OTOL.jpg"
},

{
title:"Harry Potter and the Philosopher's Stone",
genre:"Fantasy",
price:699,
discount:18,
stock:50,
featured:true,
trending:true,
description:"The magical journey begins.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81YOuOGFCJL.jpg"
},

{
title:"1984",
genre:"Novel",
price:399,
discount:8,
stock:20,
featured:false,
trending:true,
description:"Classic dystopian novel.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71kxa1-0mfL.jpg"
},

{
title:"Deep Work",
genre:"Self Help",
price:499,
discount:15,
stock:20,
featured:true,
trending:false,
description:"Focus in a distracted world.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71QKQ9mwV7L.jpg"
},

{
title:"Think and Grow Rich",
genre:"Business",
price:380,
discount:10,
stock:35,
featured:false,
trending:true,
description:"Success philosophy.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71UypkUjStL.jpg"
},

{
title:"The Hobbit",
genre:"Fantasy",
price:599,
discount:20,
stock:30,
featured:true,
trending:true,
description:"Adventure to Middle Earth.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91b0C2YNSrL.jpg"
},

{
title:"Python Crash Course",
genre:"Programming",
price:899,
discount:25,
stock:20,
featured:false,
trending:true,
description:"Learn Python practically.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81F90H7hnML.jpg"
},

{
title:"Clean Code",
genre:"Programming",
price:950,
discount:20,
stock:25,
featured:true,
trending:true,
description:"A handbook of Agile Software Craftsmanship.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/41xShlnTZTL.jpg"
},

{
title:"The Pragmatic Programmer",
genre:"Programming",
price:850,
discount:18,
stock:18,
featured:false,
trending:true,
description:"Journey to mastery.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/51A9R8L4ACL.jpg"
},

{
title:"The Monk Who Sold His Ferrari",
genre:"Self Help",
price:299,
discount:12,
stock:40,
featured:true,
trending:false,
description:"Life changing lessons.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71zytzrg6lL.jpg"
},

{
title:"Ikigai",
genre:"Self Help",
price:399,
discount:15,
stock:45,
featured:true,
trending:true,
description:"Japanese secret to long life.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81l3rZK4lnL.jpg"
},

{
title:"Zero To One",
genre:"Business",
price:450,
discount:15,
stock:22,
featured:false,
trending:true,
description:"Build the future.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71m-MxdJ2WL.jpg"
},

{
title:"Steve Jobs",
genre:"Biography",
price:650,
discount:18,
stock:15,
featured:false,
trending:false,
description:"Biography by Walter Isaacson.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81VStYnDGrL.jpg"
},

{
title:"Sapiens",
genre:"History",
price:699,
discount:20,
stock:20,
featured:true,
trending:true,
description:"Brief history of humankind.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/713jIoMO3UL.jpg"
},

{
title:"The Lean Startup",
genre:"Business",
price:480,
discount:12,
stock:30,
featured:false,
trending:true,
description:"Entrepreneurship guide.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81-QB7nDh4L.jpg"
},

{
title:"The Power of Habit",
genre:"Self Help",
price:450,
discount:15,
stock:35,
featured:true,
trending:true,
description:"Change habits forever.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71QKQ9mwV7L.jpg"
},

{
title:"The Great Gatsby",
genre:"Novel",
price:350,
discount:10,
stock:22,
featured:false,
trending:false,
description:"American classic.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81af+MCATTL.jpg"
},

{
title:"Wings of Fire",
genre:"Biography",
price:420,
discount:15,
stock:40,
featured:true,
trending:true,
description:"A.P.J Abdul Kalam autobiography.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71KKZlVjbwL.jpg"
},

{
title:"The Da Vinci Code",
genre:"Novel",
price:499,
discount:18,
stock:20,
featured:true,
trending:true,
description:"Mystery thriller.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81Q5xv4YJGL.jpg"
},

{
title:"Angels and Demons",
genre:"Novel",
price:450,
discount:12,
stock:18,
featured:false,
trending:true,
description:"Robert Langdon mystery.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81Jj7Jv2HSL.jpg"
},

{
title:"You Can Win",
genre:"Self Help",
price:350,
discount:10,
stock:25,
featured:false,
trending:false,
description:"Motivational bestseller.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71L4q5M7MPL.jpg"
},

{
title:"The Intelligent Investor",
genre:"Business",
price:899,
discount:20,
stock:15,
featured:true,
trending:true,
description:"Value investing classic.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91+t0Di07FL.jpg"
}
,

{
title:"The Silent Patient",
genre:"Mystery",
price:499,
discount:15,
stock:30,
featured:true,
trending:true,
description:"A psychological thriller full of twists.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81JJPDNlxSL.jpg"
},

{
title:"It Ends With Us",
genre:"Romance",
price:450,
discount:12,
stock:35,
featured:true,
trending:true,
description:"A bestselling contemporary romance.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81s0B6NYXML.jpg"
},

{
title:"Verity",
genre:"Thriller",
price:520,
discount:18,
stock:28,
featured:true,
trending:true,
description:"Dark psychological suspense.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91Yl2Y4VQNL.jpg"
},

{
title:"The Shining",
genre:"Horror",
price:550,
discount:15,
stock:20,
featured:false,
trending:true,
description:"Stephen King's horror masterpiece.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81M4wYJQ3QL.jpg"
},

{
title:"Doctor Sleep",
genre:"Horror",
price:620,
discount:15,
stock:18,
featured:false,
trending:false,
description:"Sequel to The Shining.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81Mf4L8N0EL.jpg"
},

{
title:"Dune",
genre:"Science Fiction",
price:699,
discount:20,
stock:25,
featured:true,
trending:true,
description:"Epic science fiction novel.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91A8R6J0K-L.jpg"
},

{
title:"Project Hail Mary",
genre:"Science Fiction",
price:749,
discount:18,
stock:22,
featured:true,
trending:true,
description:"A thrilling space adventure.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91cjUoA2u-L.jpg"
},

{
title:"The Martian",
genre:"Science Fiction",
price:650,
discount:18,
stock:24,
featured:false,
trending:true,
description:"Survival story on Mars.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91vS2L5sYDL.jpg"
},

{
title:"Digital Fortress",
genre:"Thriller",
price:430,
discount:10,
stock:30,
featured:false,
trending:false,
description:"Cyber security thriller.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81JY9T5QSQL.jpg"
},

{
title:"Inferno",
genre:"Thriller",
price:520,
discount:15,
stock:25,
featured:true,
trending:true,
description:"Robert Langdon returns.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91n6xj7B3nL.jpg"
},

{
title:"Five Point Someone",
genre:"Novel",
price:299,
discount:10,
stock:50,
featured:false,
trending:true,
description:"College life at IIT.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81M0GB3M7XL.jpg"
},

{
title:"Half Girlfriend",
genre:"Romance",
price:350,
discount:10,
stock:40,
featured:true,
trending:true,
description:"A modern Indian romance.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81QpkIctqPL.jpg"
},

{
title:"One Indian Girl",
genre:"Romance",
price:340,
discount:12,
stock:35,
featured:false,
trending:false,
description:"Story of an independent woman.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81OGqGm+E8L.jpg"
},

{
title:"The Blue Umbrella",
genre:"Novel",
price:250,
discount:8,
stock:30,
featured:false,
trending:false,
description:"A beautiful Himalayan tale.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71vH8D5Q2QL.jpg"
},

{
title:"Roads to Mussoorie",
genre:"Travel",
price:320,
discount:10,
stock:20,
featured:false,
trending:false,
description:"Travel stories by Ruskin Bond.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71FgkTTMZWL.jpg"
},

{
title:"Artificial Intelligence Basics",
genre:"Technology",
price:850,
discount:20,
stock:20,
featured:true,
trending:true,
description:"Introduction to AI.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71LJLg7Q3SL.jpg"
},

{
title:"Hands-On Machine Learning",
genre:"Technology",
price:1199,
discount:25,
stock:15,
featured:true,
trending:true,
description:"Machine Learning with Python.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/81CC4KYhSAL.jpg"
},

{
title:"Learning React",
genre:"Programming",
price:780,
discount:20,
stock:25,
featured:true,
trending:true,
description:"Modern React development.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71lQ4kceQ-L.jpg"
},

{
title:"Node.js Design Patterns",
genre:"Programming",
price:950,
discount:18,
stock:18,
featured:false,
trending:true,
description:"Professional Node.js practices.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91T4A6NQJFL.jpg"
},

{
title:"Eloquent JavaScript",
genre:"Programming",
price:799,
discount:15,
stock:20,
featured:false,
trending:true,
description:"Modern JavaScript guide.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91asIC1fRwL.jpg"
},

{
title:"Java: The Complete Reference",
genre:"Programming",
price:999,
discount:20,
stock:18,
featured:true,
trending:true,
description:"Comprehensive Java programming.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91YPlR5S3UL.jpg"
},

{
title:"Operating System Concepts",
genre:"Technology",
price:950,
discount:15,
stock:15,
featured:false,
trending:false,
description:"Operating systems fundamentals.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91VwR39H1QL.jpg"
},

{
title:"Computer Networks",
genre:"Technology",
price:899,
discount:15,
stock:20,
featured:false,
trending:true,
description:"Networking concepts explained.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91jK9L5QjQL.jpg"
},

{
title:"The C Programming Language",
genre:"Programming",
price:650,
discount:12,
stock:25,
featured:true,
trending:false,
description:"Classic C programming book.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/71HA3mP2ZDL.jpg"
},

{
title:"Introduction to Algorithms",
genre:"Programming",
price:1450,
discount:20,
stock:10,
featured:true,
trending:true,
description:"The famous CLRS algorithms book.",
coverImage:"https://images-na.ssl-images-amazon.com/images/I/91Mw+Kz5P-L.jpg"
}


];