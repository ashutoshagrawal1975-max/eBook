const mongoose = require("mongoose");
const dotenv = require("dotenv");

dotenv.config();

const connectDB = require("../config/db");

const Author = require("../models/Author");
const Book = require("../models/Book");
const Category = require("../models/Category");
const Banner = require("../models/Banner");

const authors = require("./authors");
const books = require("./books");

const seedDatabase = async () => {

    try {

        await connectDB();

        console.log("=================================");
        console.log("Connected Database :", Book.db.name);
        console.log("=================================");

        // Delete old data
        await Author.deleteMany({});
        await Book.deleteMany({});
        await Category.deleteMany({});
        await Banner.deleteMany({});

        console.log("Old data deleted successfully.");

        // Insert Authors
        const createdAuthors = await Author.insertMany(authors);

        console.log("Authors inserted :", createdAuthors.length);

        // Categories
        const categoryNames = [
            "Programming",
            "Self Help",
            "Business",
            "Fantasy",
            "Novel",
            "History",
            "Biography",
            "Technology",
            "Science",
            "Romance"
        ];

        const categories = categoryNames.map(name => ({
            name
        }));

        const insertedCategories = await Category.insertMany(categories);

        console.log("Categories inserted :", insertedCategories.length);

        // Books
        const finalBooks = books.map((book, index) => ({
            ...book,
            author: createdAuthors[index % createdAuthors.length]._id
        }));

        const insertedBooks = await Book.insertMany(finalBooks);

        console.log("Books inserted :", insertedBooks.length);

        // Banners
        const insertedBanners = await Banner.insertMany([
            {
                title: "Summer Book Sale",
                subtitle: "Up to 50% Off",
                image: "https://images.unsplash.com/photo-1512820790803-83ca734da794",
                buttonText: "Shop Now"
            },
            {
                title: "Best Selling Books",
                subtitle: "Read Something Amazing",
                image: "https://images.unsplash.com/photo-1524578271613-d550eacf6090",
                buttonText: "Explore"
            },
            {
                title: "Free Delivery",
                subtitle: "On Orders Above ₹499",
                image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d",
                buttonText: "Browse"
            }
        ]);

        console.log("Banners inserted :", insertedBanners.length);

        console.log("=================================");
        console.log("Database Seeded Successfully");
        console.log("=================================");

        process.exit(0);

    } catch (error) {

        console.log("Seed Error:");
        console.log(error);

        process.exit(1);

    }

};

seedDatabase();