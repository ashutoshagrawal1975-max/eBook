const express = require("express");

const router = express.Router();


const {

getAuthors,

getAuthorById,

getAuthorBooks

} = require("../controllers/authorController");



router.get(
"/",
getAuthors
);



router.get(
"/:id/books",
getAuthorBooks
);



router.get(
"/:id",
getAuthorById
);



module.exports = router;