const express = require("express");

const router = express.Router();

const protect = require("../middleware/authMiddleware");

const {

    addReview,

    getBookReviews

} = require("../controllers/reviewController");


router.post(

    "/",

    protect,

    addReview

);


router.get(

    "/:bookId",

    getBookReviews

);


module.exports = router;