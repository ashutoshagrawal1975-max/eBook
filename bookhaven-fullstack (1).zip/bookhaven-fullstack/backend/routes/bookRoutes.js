const express = require("express");

const router = express.Router();


const {

getBooks,

getBookById,

searchBooks,

getBooksByCategory,

getFeaturedBooks,

getTrendingBooks


}=require("../controllers/bookController");



router.get(
"/",
getBooks
);



router.get(
"/search",
searchBooks
);



router.get(
"/featured",
getFeaturedBooks
);



router.get(
"/trending",
getTrendingBooks
);



router.get(
"/category/:genre",
getBooksByCategory
);



router.get(
"/:id",
getBookById
);



module.exports = router;