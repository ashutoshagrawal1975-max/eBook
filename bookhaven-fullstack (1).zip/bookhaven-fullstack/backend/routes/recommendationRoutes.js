const express = require("express");

const router = express.Router();

const {

    getRelatedBooks,

    getFeaturedBooks

} = require("../controllers/recommendationController");


router.get(

    "/featured",

    getFeaturedBooks

);


router.get(

    "/related/:bookId",

    getRelatedBooks

);

module.exports = router;