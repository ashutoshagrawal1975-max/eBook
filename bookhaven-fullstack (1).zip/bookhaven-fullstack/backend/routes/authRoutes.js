const express = require("express");

const router = express.Router();


const {

register,

verifyEmail,

login,

forgotPassword,

resetPassword,

getProfile


}=require("../controllers/authController");



const protect =
require("../middleware/authMiddleware");



router.post(
"/register",
register
);


router.post(
"/verify-email",
verifyEmail
);


router.post(
"/login",
login
);



router.post(
"/forgot-password",
forgotPassword
);



router.post(
"/reset-password",
resetPassword
);



router.get(
"/me",
protect,
getProfile
);



module.exports=router;