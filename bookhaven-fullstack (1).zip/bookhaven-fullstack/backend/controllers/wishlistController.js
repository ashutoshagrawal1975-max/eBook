const Wishlist = require("../models/Wishlist");
const Book = require("../models/Book");


// GET WISHLIST

const getWishlist = async (req, res) => {

    try {

        let wishlist = await Wishlist.findOne({
            user: req.user._id
        }).populate("books");

        if (!wishlist) {

            wishlist = await Wishlist.create({
                user: req.user._id,
                books: []
            });

        }

        res.json({
            success: true,
            wishlist
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};




// ADD BOOK

const addToWishlist = async (req, res) => {

    try {

        const { bookId } = req.body;

        const book = await Book.findById(bookId);

        if (!book) {

            return res.status(404).json({
                success: false,
                message: "Book not found"
            });

        }

        let wishlist = await Wishlist.findOne({
            user: req.user._id
        });

        if (!wishlist) {

            wishlist = await Wishlist.create({
                user: req.user._id,
                books: []
            });

        }

        const exists = wishlist.books.find(

            item => item.toString() === bookId

        );

        if (exists) {

            return res.status(400).json({
                success: false,
                message: "Book already in wishlist"
            });

        }

        wishlist.books.push(bookId);

        await wishlist.save();

        const updatedWishlist = await Wishlist.findById(wishlist._id)
            .populate("books");

        res.json({
            success: true,
            message: "Book added to wishlist",
            wishlist: updatedWishlist
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};




// REMOVE BOOK

const removeFromWishlist = async (req, res) => {

    try {

        const wishlist = await Wishlist.findOne({
            user: req.user._id
        });

        if (!wishlist) {

            return res.status(404).json({
                success: false,
                message: "Wishlist not found"
            });

        }

        wishlist.books = wishlist.books.filter(

            book => book.toString() !== req.params.bookId

        );

        await wishlist.save();

        res.json({
            success: true,
            message: "Book removed from wishlist",
            wishlist
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

module.exports = {

    getWishlist,

    addToWishlist,

    removeFromWishlist

};