const Category = require("../models/Category");


// GET ALL CATEGORIES

const getCategories = async (req, res) => {

    try {

        const categories = await Category.find({
            active: true
        });

        res.json({

            success: true,

            count: categories.length,

            categories

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};


// GET SINGLE CATEGORY

const getCategory = async (req, res) => {

    try {

        const category = await Category.findById(req.params.id);

        if (!category) {

            return res.status(404).json({

                success: false,

                message: "Category not found"

            });

        }

        res.json({

            success: true,

            category

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    getCategories,

    getCategory

};