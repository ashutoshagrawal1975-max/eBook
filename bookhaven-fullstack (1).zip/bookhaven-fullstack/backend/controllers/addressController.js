const Address = require("../models/Address");


// GET ALL ADDRESSES

const getAddresses = async(req,res)=>{

    try{

        const addresses = await Address.find({

            user:req.user._id

        });

        res.json({

            success:true,

            addresses

        });

    }

    catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};




// ADD ADDRESS

const addAddress = async(req,res)=>{

    try{

        const address = await Address.create({

            ...req.body,

            user:req.user._id

        });

        res.status(201).json({

            success:true,

            address

        });

    }

    catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};




// DELETE ADDRESS

const deleteAddress = async(req,res)=>{

    try{

        await Address.findByIdAndDelete(req.params.id);

        res.json({

            success:true,

            message:"Address deleted"

        });

    }

    catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};

module.exports={

    getAddresses,

    addAddress,

    deleteAddress

};