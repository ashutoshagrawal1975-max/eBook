const Cart = require("../models/Cart");
const Book = require("../models/Book");


// GET CART

const getCart = async (req, res) => {

    try {

        let cart = await Cart.findOne({
            user: req.user._id
        }).populate("items.book");

        if (!cart) {

            cart = await Cart.create({
                user: req.user._id,
                items: []
            });

        }

        res.json({
            success: true,
            cart
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};




// ADD TO CART

const addToCart = async (req, res) => {

    try {

        const { bookId, quantity = 1 } = req.body;

        const book = await Book.findById(bookId);

        if (!book) {

            return res.status(404).json({
                success: false,
                message: "Book not found"
            });

        }

        let cart = await Cart.findOne({
            user: req.user._id
        });

        if (!cart) {

            cart = await Cart.create({
                user: req.user._id,
                items: []
            });

        }

        const index = cart.items.findIndex(
            item => item.book.toString() === bookId
        );

        if (index !== -1) {

            cart.items[index].quantity += quantity;

        } else {

            cart.items.push({
                book: bookId,
                quantity
            });

        }

        await cart.save();

        const updatedCart = await Cart.findById(cart._id)
            .populate("items.book");

        res.json({
            success: true,
            message: "Book added to cart",
            cart: updatedCart
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};




// UPDATE QUANTITY

const updateCartItem = async (req, res) => {

    try {

        const { bookId, quantity } = req.body;

        const cart = await Cart.findOne({
            user: req.user._id
        });

        if (!cart) {

            return res.status(404).json({
                success: false,
                message: "Cart not found"
            });

        }

        const item = cart.items.find(
            item => item.book.toString() === bookId
        );

        if (!item) {

            return res.status(404).json({
                success: false,
                message: "Book not found in cart"
            });

        }

        item.quantity = quantity;

        await cart.save();

        res.json({
            success: true,
            message: "Quantity updated",
            cart
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};




// REMOVE ITEM

const removeCartItem = async (req, res) => {

    try {

        const cart = await Cart.findOne({
            user: req.user._id
        });

        if (!cart) {

            return res.status(404).json({
                success: false,
                message: "Cart not found"
            });

        }

        cart.items = cart.items.filter(

            item => item.book.toString() !== req.params.bookId

        );

        await cart.save();

        res.json({

            success: true,

            message: "Book removed",

            cart

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};




// CLEAR CART

const clearCart = async (req, res) => {

    try {

        const cart = await Cart.findOne({
            user: req.user._id
        });

        if (!cart) {

            return res.status(404).json({

                success: false,

                message: "Cart not found"

            });

        }

        cart.items = [];

        await cart.save();

        res.json({

            success: true,

            message: "Cart cleared"

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {
    getCart,
    addToCart,
    updateCartItem,
    removeCartItem,
    clearCart
};