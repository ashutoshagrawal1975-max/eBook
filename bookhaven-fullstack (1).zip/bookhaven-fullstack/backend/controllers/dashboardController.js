const Cart = require("../models/Cart");
const Wishlist = require("../models/Wishlist");
const Order = require("../models/Order");

const getDashboard = async (req, res) => {

    try {

        const cart = await Cart.findOne({

            user: req.user._id

        });

        const wishlist = await Wishlist.findOne({

            user: req.user._id

        });

        const orders = await Order.find({

            user: req.user._id

        });

        res.json({

            success: true,

            dashboard: {

                cartItems: cart ? cart.items.length : 0,

                wishlistItems: wishlist ? wishlist.books.length : 0,

                totalOrders: orders.length,

                recentOrders: orders.slice(0,5)

            }

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    getDashboard

};