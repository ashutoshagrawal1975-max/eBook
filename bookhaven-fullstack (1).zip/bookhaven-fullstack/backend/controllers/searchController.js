const Book = require("../models/Book");

const searchBooks = async(req,res)=>{

try{

const keyword=req.query.keyword || "";

const books=await Book.find({

title:{

$regex:keyword,

$options:"i"

}

}).populate("author");

res.json({

success:true,

count:books.length,

books

});

}

catch(error){

res.status(500).json({

success:false,

message:error.message

});

}

};

module.exports={

searchBooks

};