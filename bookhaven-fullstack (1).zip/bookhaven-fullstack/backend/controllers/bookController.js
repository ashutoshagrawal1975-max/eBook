const Book = require("../models/Book");


// GET ALL BOOKS

const getBooks = async (req, res) => {

    try {

        const books = await Book.find()
            .populate("author", "name image");


        res.json({

            success: true,

            count: books.length,

            books

        });


    } catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};




// GET SINGLE BOOK


const getBookById = async(req,res)=>{

    try{


        const book =
        await Book.findById(req.params.id)
        .populate("author");


        if(!book){

            return res.status(404).json({

                success:false,

                message:"Book not found"

            });

        }



        res.json({

            success:true,

            book

        });


    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};





// SEARCH BOOKS


const searchBooks = async(req,res)=>{


    try{


        const keyword =
        req.query.keyword || "";



        const books =
        await Book.find({

            title:{
                $regex:keyword,
                $options:"i"
            }

        })
        .populate("author","name");



        res.json({

            success:true,

            books

        });



    }catch(error){


        res.status(500).json({

            success:false,

            message:error.message

        });


    }


};







// CATEGORY FILTER


const getBooksByCategory =
async(req,res)=>{


    try{


        const books =
        await Book.find({

            genre:req.params.genre

        })
        .populate(
            "author",
            "name"
        );



        res.json({

            success:true,

            books

        });



    }catch(error){


        res.status(500).json({

            success:false,

            message:error.message

        });


    }


};







// FEATURED BOOKS


const getFeaturedBooks =
async(req,res)=>{


    try{


        const books =
        await Book.find({

            featured:true

        })
        .populate(
            "author",
            "name"
        );


        res.json({

            success:true,

            books

        });


    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};







// TRENDING BOOKS


const getTrendingBooks =
async(req,res)=>{


    try{


        const books =
        await Book.find({

            trending:true

        })
        .populate(
            "author",
            "name"
        );



        res.json({

            success:true,

            books

        });


    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};





module.exports={

    getBooks,

    getBookById,

    searchBooks,

    getBooksByCategory,

    getFeaturedBooks,

    getTrendingBooks

};