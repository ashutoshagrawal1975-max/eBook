const Banner=require("../models/Banner");


// GET ACTIVE BANNERS

const getBanners=async(req,res)=>{

try{

const banners=await Banner.find({

active:true

});

res.json({

success:true,

banners

});

}

catch(error){

res.status(500).json({

success:false,

message:error.message

});

}

};

module.exports={

getBanners

};