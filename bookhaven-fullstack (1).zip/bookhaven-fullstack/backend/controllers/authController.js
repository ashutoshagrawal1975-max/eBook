const User = require("../models/User");
const bcrypt = require("bcrypt");

const generateOTP = require("../utils/generateOTP");
const sendEmail = require("../services/emailService");
const generateToken = require("../utils/generateToken");


// REGISTER

const register = async (req, res) => {

    try {

        const { name, email, password } = req.body;


        const existingUser = await User.findOne({ email });


        if(existingUser){

            return res.status(400).json({
                success:false,
                message:"Email already registered"
            });

        }


        const hashedPassword =
            await bcrypt.hash(password,12);


        const otp = generateOTP();


        await User.create({

            name,

            email,

            password:hashedPassword,

            verificationOTP:otp,

            verificationOTPExpire:
            Date.now()+10*60*1000

        });



        await sendEmail(

            email,

            "E-Book Store Email Verification",

            `
            <h2>E-Book Store</h2>

            <p>Your verification OTP is:</p>

            <h1>${otp}</h1>

            <p>Valid for 10 minutes.</p>
            `

        );


        res.status(201).json({

            success:true,

            message:"OTP sent to email"

        });


    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};





// VERIFY EMAIL


const verifyEmail = async(req,res)=>{

    try{


        const {email,otp}=req.body;


        const user =
        await User.findOne({email});


        if(!user){

            return res.status(404).json({

                success:false,

                message:"User not found"

            });

        }



        if(

            user.verificationOTP!==otp ||

            user.verificationOTPExpire<Date.now()

        ){

            return res.status(400).json({

                success:false,

                message:"Invalid OTP"

            });

        }



        user.isVerified=true;

        user.verificationOTP="";

        user.verificationOTPExpire=null;



        await user.save();



        res.json({

            success:true,

            message:"Email verified"

        });



    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};





// LOGIN


const login = async(req,res)=>{


    try{


        const {email,password}=req.body;



        const user =
        await User.findOne({email});



        if(!user){

            return res.status(401).json({

                success:false,

                message:"Invalid credentials"

            });

        }



        if(!user.isVerified){

            return res.status(401).json({

                success:false,

                message:"Verify email first"

            });

        }



        const valid =
        await bcrypt.compare(
            password,
            user.password
        );



        if(!valid){

            return res.status(401).json({

                success:false,

                message:"Invalid credentials"

            });

        }



        const token =
        generateToken(user._id);



        res.json({

            success:true,

            token,

            user:{

                id:user._id,

                name:user.name,

                email:user.email

            }

        });



    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }


};






// FORGOT PASSWORD


const forgotPassword = async(req,res)=>{


    try{


        const {email}=req.body;


        const user =
        await User.findOne({email});


        if(!user){

            return res.status(404).json({

                success:false,

                message:"Email not found"

            });

        }



        const otp =
        generateOTP();



        user.resetPasswordOTP=otp;


        user.resetPasswordOTPExpire =
        Date.now()+10*60*1000;



        await user.save();



        await sendEmail(

            email,

            "Reset Password OTP",

            `
            <h2>Password Reset</h2>

            <p>Your OTP is:</p>

            <h1>${otp}</h1>

            `

        );



        res.json({

            success:true,

            message:"Reset OTP sent"

        });



    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};






// RESET PASSWORD


const resetPassword = async(req,res)=>{


    try{


        const {
            email,
            otp,
            password
        }=req.body;



        const user =
        await User.findOne({email});



        if(!user){

            return res.status(404).json({

                success:false,

                message:"User not found"

            });

        }




        if(

            user.resetPasswordOTP!==otp ||

            user.resetPasswordOTPExpire<Date.now()

        ){

            return res.status(400).json({

                success:false,

                message:"Invalid OTP"

            });

        }




        user.password =
        await bcrypt.hash(password,12);



        user.resetPasswordOTP="";

        user.resetPasswordOTPExpire=null;



        await user.save();



        res.json({

            success:true,

            message:"Password updated"

        });



    }catch(error){


        res.status(500).json({

            success:false,

            message:error.message

        });


    }

};





// GET PROFILE


const getProfile = async(req,res)=>{


    res.json({

        success:true,

        user:req.user

    });


};





module.exports={

    register,

    verifyEmail,

    login,

    forgotPassword,

    resetPassword,

    getProfile

};