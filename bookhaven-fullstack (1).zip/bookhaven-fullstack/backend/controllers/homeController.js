const Banner = require("../models/Banner");
const Book = require("../models/Book");
const Author = require("../models/Author");
const Category = require("../models/Category");

const getHomeData = async (req, res) => {

    try {

        const banners = await Banner.find({ active: true });

        const featuredBooks = await Book.find({ featured: true })
            .populate("author")
            .limit(8);

        const trendingBooks = await Book.find({ trending: true })
            .populate("author")
            .limit(8);

        const newArrivals = await Book.find()
            .sort({ createdAt: -1 })
            .populate("author")
            .limit(8);

        const authors = await Author.find().limit(10);

        const categories = await Category.find({ active: true });

        res.json({

            success: true,

            banners,

            featuredBooks,

            trendingBooks,

            newArrivals,

            authors,

            categories

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    getHomeData

};