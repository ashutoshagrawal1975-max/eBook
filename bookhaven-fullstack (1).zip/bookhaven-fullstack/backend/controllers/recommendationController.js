const Book = require("../models/Book");


// RELATED BOOKS

const getRelatedBooks = async (req, res) => {

    try {

        const currentBook = await Book.findById(req.params.bookId);

        if (!currentBook) {

            return res.status(404).json({

                success: false,

                message: "Book not found"

            });

        }

        const books = await Book.find({

            genre: currentBook.genre,

            _id: { $ne: currentBook._id }

        })

        .populate("author")

        .limit(8);

        res.json({

            success: true,

            books

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};




// FEATURED BOOKS

const getFeaturedBooks = async (req, res) => {

    try {

        const books = await Book.find({

            featured: true

        })

        .populate("author")

        .limit(10);

        res.json({

            success: true,

            books

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    getRelatedBooks,

    getFeaturedBooks

};