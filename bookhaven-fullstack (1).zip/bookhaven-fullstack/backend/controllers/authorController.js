const Author = require("../models/Author");
const Book = require("../models/Book");


// GET ALL AUTHORS

const getAuthors = async (req, res) => {

    try {

        const authors = await Author.find();


        res.json({

            success: true,

            count: authors.length,

            authors

        });


    } catch(error) {

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};





// GET SINGLE AUTHOR


const getAuthorById = async(req,res)=>{

    try{


        const author =
        await Author.findById(req.params.id);


        if(!author){

            return res.status(404).json({

                success:false,

                message:"Author not found"

            });

        }



        res.json({

            success:true,

            author

        });



    }catch(error){

        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};






// GET AUTHOR BOOKS


const getAuthorBooks = async(req,res)=>{

    try{


        const books =
        await Book.find({

            author:req.params.id

        })
        .populate(
            "author",
            "name image"
        );



        res.json({

            success:true,

            books

        });



    }catch(error){


        res.status(500).json({

            success:false,

            message:error.message

        });


    }

};





module.exports={

    getAuthors,

    getAuthorById,

    getAuthorBooks

};