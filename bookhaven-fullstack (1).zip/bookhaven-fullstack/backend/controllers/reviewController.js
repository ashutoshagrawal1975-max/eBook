const Review = require("../models/Review");
const Book = require("../models/Book");


// ADD REVIEW

const addReview = async (req, res) => {

    try {

        const {
            bookId,
            rating,
            comment
        } = req.body;


        const book = await Book.findById(bookId);

        if (!book) {

            return res.status(404).json({
                success: false,
                message: "Book not found"
            });

        }


        const alreadyReviewed = await Review.findOne({

            user: req.user._id,

            book: bookId

        });


        if (alreadyReviewed) {

            return res.status(400).json({

                success: false,

                message: "Review already submitted"

            });

        }


        const review = await Review.create({

            user: req.user._id,

            book: bookId,

            rating,

            comment

        });


        const reviews = await Review.find({

            book: bookId

        });


        const average = reviews.reduce(

            (sum, item) => sum + item.rating,

            0

        ) / reviews.length;


        book.ratings.average = average;

        book.ratings.count = reviews.length;

        await book.save();


        res.status(201).json({

            success: true,

            review

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};




// GET REVIEWS

const getBookReviews = async (req, res) => {

    try {

        const reviews = await Review.find({

            book: req.params.bookId

        }).populate(

            "user",

            "name avatar"

        );


        res.json({

            success: true,

            reviews

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    addReview,

    getBookReviews

};