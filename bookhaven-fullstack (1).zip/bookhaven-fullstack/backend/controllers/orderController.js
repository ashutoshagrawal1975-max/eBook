const Order = require("../models/Order");
const Cart = require("../models/Cart");


// PLACE ORDER

const placeOrder = async (req, res) => {

    try {

        const { paymentMethod, shippingAddress } = req.body;

        if (paymentMethod === "UPI") {

            return res.status(400).json({

                success: false,

                message: "UPI payment is coming soon."

            });

        }

        const cart = await Cart.findOne({
            user: req.user._id
        }).populate("items.book");

        if (!cart || cart.items.length === 0) {

            return res.status(400).json({

                success: false,

                message: "Cart is empty"

            });

        }

        const items = cart.items.map(item => ({

            book: item.book._id,

            quantity: item.quantity,

            price: item.book.price

        }));

        const totalAmount = cart.items.reduce(

            (sum, item) => sum + item.book.price * item.quantity,

            0

        );

        const order = await Order.create({

            user: req.user._id,

            items,

            totalAmount,

            paymentMethod,

            shippingAddress

        });

        cart.items = [];

        await cart.save();

        res.status(201).json({

            success: true,

            message: "Order placed successfully",

            order

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};




// MY ORDERS

const getMyOrders = async (req, res) => {

    try {

        const orders = await Order.find({

            user: req.user._id

        }).populate("items.book");

        res.json({

            success: true,

            orders

        });

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    placeOrder,

    getMyOrders

};