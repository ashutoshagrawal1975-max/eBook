const User = require("../models/User");


// GET PROFILE

const getProfile = async (req, res) => {

    try {

        const user = await User.findById(req.user._id)
            .select("-password -verificationOTP -resetOTP");

        res.json({

            success: true,

            user

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};




// UPDATE PROFILE

const updateProfile = async (req, res) => {

    try {

        const {

            name,

            phone,

            address,

            avatar

        } = req.body;


        const user = await User.findById(req.user._id);

        if (!user) {

            return res.status(404).json({

                success: false,

                message: "User not found"

            });

        }


        user.name = name || user.name;
        user.phone = phone || user.phone;
        user.address = address || user.address;
        user.avatar = avatar || user.avatar;

        await user.save();

        res.json({

            success: true,

            message: "Profile updated",

            user

        });

    }

    catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

};

module.exports = {

    getProfile,

    updateProfile

};