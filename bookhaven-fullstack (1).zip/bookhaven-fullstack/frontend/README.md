# BookHaven – E-Book Store Frontend

React + Vite frontend for the BookHaven e-book store.

## Setup

```bash
npm install
```

Create a `.env` file (copy from `.env.example`):
```
VITE_API_URL=http://localhost:5000
```

## Run

```bash
npm run dev
```

Open http://localhost:5173

## Build for production

```bash
npm run build
```

## Backend

This frontend connects to your Node.js / Express + MongoDB backend.
Make sure your backend is running and CORS is enabled for the frontend origin.
