import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, Router as WouterRouter } from "wouter";
import { AuthProvider } from "@/context/AuthContext";

import "./index.css";

import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ProtectedRoute } from "@/components/ProtectedRoute";

// Pages
import { Home } from "@/pages/Home";
import { Books } from "@/pages/Books";
import { BookDetail } from "@/pages/BookDetail";
import { Categories } from "@/pages/Categories";
import { Authors } from "@/pages/Authors";
import { AuthorDetail } from "@/pages/AuthorDetail";
import { Search } from "@/pages/Search";
import { Login } from "@/pages/Login";
import { Register } from "@/pages/Register";
import { VerifyEmail } from "@/pages/VerifyEmail";
import { ForgotPassword } from "@/pages/ForgotPassword";
import { ResetPassword } from "@/pages/ResetPassword";
import { Cart } from "@/pages/Cart";
import { Wishlist } from "@/pages/Wishlist";
import { Checkout } from "@/pages/Checkout";
import { Orders } from "@/pages/Orders";
import { Profile } from "@/pages/Profile";

import NotFound from "@/pages/not-found";


const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/books" component={Books} />
          <Route path="/books/:id" component={BookDetail} />
          <Route path="/categories" component={Categories} />
          <Route path="/authors" component={Authors} />
          <Route path="/authors/:id" component={AuthorDetail} />
          <Route path="/search" component={Search} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/verify-email" component={VerifyEmail} />
          <Route path="/forgot-password" component={ForgotPassword} />
          <Route path="/reset-password" component={ResetPassword} />
          
          <Route path="/cart"><ProtectedRoute component={Cart} /></Route>
          <Route path="/wishlist"><ProtectedRoute component={Wishlist} /></Route>
          <Route path="/checkout"><ProtectedRoute component={Checkout} /></Route>
          <Route path="/orders"><ProtectedRoute component={Orders} /></Route>
          <Route path="/profile"><ProtectedRoute component={Profile} /></Route>
          <Route path="/dashboard"><ProtectedRoute component={Profile} /></Route>

          <Route component={NotFound} />
        </Switch>
      </div>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base="">
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);
