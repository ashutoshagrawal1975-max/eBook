import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useGetProfile, useUpdateProfile, useGetAddresses, useAddAddress, useUpdateAddress, useDeleteAddress, useGetDashboard } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { UserCircle, MapPin, Heart, ShoppingBag, Package, Trash2, Edit } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().optional(),
  avatar: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

const addressSchema = z.object({
  fullName: z.string().min(2, "Full name required"),
  mobile: z.string().min(10, "Valid mobile required"),
  address: z.string().min(5, "Address required"),
  city: z.string().min(2, "City required"),
  state: z.string().min(2, "State required"),
  pincode: z.string().min(4, "Pincode required"),
  country: z.string().default("USA"),
  isDefault: z.boolean().default(false),
});

export function Profile() {
  const { user, login } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState(null);

  // Queries
  const { data: profileData } = useGetProfile({ query: { queryKey: ["profile"] } });
  const { data: addressData, isLoading: addrLoading } = useGetAddresses({ query: { queryKey: ["addresses"] } });
  const { data: dashboardData } = useGetDashboard({ query: { queryKey: ["dashboard"] } });

  // Mutations
  const updateProfileMutation = useUpdateProfile({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Profile updated" });
        if (data.user) {
          login(localStorage.getItem("bookhaven_token"), data.user);
        }
      }
    }
  });

  const addAddressMutation = useAddAddress({
    mutation: {
      onSuccess: () => {
        toast({ title: "Address added" });
        setIsAddressModalOpen(false);
        queryClient.invalidateQueries({ queryKey: ["addresses"] });
      }
    }
  });

  const updateAddressMutation = useUpdateAddress({
    mutation: {
      onSuccess: () => {
        toast({ title: "Address updated" });
        setIsAddressModalOpen(false);
        queryClient.invalidateQueries({ queryKey: ["addresses"] });
      }
    }
  });

  const deleteAddressMutation = useDeleteAddress({
    mutation: {
      onSuccess: () => {
        toast({ title: "Address deleted" });
        queryClient.invalidateQueries({ queryKey: ["addresses"] });
      }
    }
  });

  // Forms
  const profileForm = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      phone: user?.phone || "",
      avatar: user?.avatar || "",
    }
  });

  useEffect(() => {
    if (profileData?.user) {
      profileForm.reset({
        name: profileData.user.name || "",
        phone: profileData.user.phone || "",
        avatar: profileData.user.avatar || "",
      });
    }
  }, [profileData, profileForm]);

  const addressForm = useForm({
    resolver: zodResolver(addressSchema),
    defaultValues: {
      fullName: "", mobile: "", address: "", city: "", state: "", pincode: "", country: "USA", isDefault: false
    }
  });

  const onSubmitProfile = (data) => updateProfileMutation.mutate({ data });

  const onSubmitAddress = (data) => {
    if (editingAddressId) {
      updateAddressMutation.mutate({ id: editingAddressId, data });
    } else {
      addAddressMutation.mutate({ data });
    }
  };

  const handleEditAddress = (addr) => {
    setEditingAddressId(addr._id);
    addressForm.reset({
      fullName: addr.fullName, mobile: addr.mobile, address: addr.address,
      city: addr.city, state: addr.state, pincode: addr.pincode,
      country: addr.country || "USA", isDefault: addr.isDefault || false
    });
    setIsAddressModalOpen(true);
  };

  const handleAddAddressClick = () => {
    setEditingAddressId(null);
    addressForm.reset({
      fullName: "", mobile: "", address: "", city: "", state: "", pincode: "", country: "USA", isDefault: false
    });
    setIsAddressModalOpen(true);
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Info */}
        <div className="w-full md:w-1/4">
          <Card className="border-primary/10 shadow-sm text-center pt-8">
            <CardContent className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-muted mb-4 shadow-sm">
                {user?.avatar ? (
                  <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <UserCircle className="w-full h-full text-muted-foreground bg-muted" />
                )}
              </div>
              <h2 className="font-serif text-2xl font-bold">{user?.name}</h2>
              <p className="text-muted-foreground text-sm">{user?.email}</p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-primary/5 p-4 rounded-xl text-center border border-primary/10">
              <Package className="h-6 w-6 text-primary mx-auto mb-2" />
              <div className="font-bold text-xl">{dashboardData?.ordersCount || 0}</div>
              <div className="text-xs text-muted-foreground">Orders</div>
            </div>
            <div className="bg-accent/10 p-4 rounded-xl text-center border border-accent/20">
              <Heart className="h-6 w-6 text-accent mx-auto mb-2" />
              <div className="font-bold text-xl">{dashboardData?.wishlistCount || 0}</div>
              <div className="text-xs text-muted-foreground">Wishlist</div>
            </div>
          </div>
        </div>

        {/* Main Content Tabs */}
        <div className="w-full md:w-3/4">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-muted/50 p-1 mb-8">
              <TabsTrigger value="profile">Personal Info</TabsTrigger>
              <TabsTrigger value="addresses">Saved Addresses</TabsTrigger>
            </TabsList>
            
            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card className="border-primary/10 shadow-sm">
                <CardHeader>
                  <CardTitle className="font-serif text-2xl">Profile Settings</CardTitle>
                  <CardDescription>Update your personal details here.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...profileForm}>
                    <form onSubmit={profileForm.handleSubmit(onSubmitProfile)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField control={profileForm.control} name="name" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl><Input {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}/>
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <Input value={user?.email || ""} disabled className="bg-muted" />
                        </FormItem>
                        <FormField control={profileForm.control} name="phone" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl><Input {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}/>
                        <FormField control={profileForm.control} name="avatar" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Avatar URL</FormLabel>
                            <FormControl><Input placeholder="https://..." {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )}/>
                      </div>
                      <Button type="submit" disabled={updateProfileMutation.isPending}>
                        {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Addresses Tab */}
            <TabsContent value="addresses">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-serif text-2xl font-bold">Your Addresses</h3>
                <Dialog open={isAddressModalOpen} onOpenChange={setIsAddressModalOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={handleAddAddressClick}>
                      <Plus className="h-4 w-4 mr-2" /> Add New
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle className="font-serif">{editingAddressId ? "Edit Address" : "Add New Address"}</DialogTitle>
                    </DialogHeader>
                    <Form {...addressForm}>
                      <form onSubmit={addressForm.handleSubmit(onSubmitAddress)} className="space-y-4 pt-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField control={addressForm.control} name="fullName" render={({ field }) => (
                            <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={addressForm.control} name="mobile" render={({ field }) => (
                            <FormItem><FormLabel>Mobile</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                        </div>
                        <FormField control={addressForm.control} name="address" render={({ field }) => (
                          <FormItem><FormLabel>Street Address</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                        )}/>
                        <div className="grid grid-cols-2 gap-4">
                          <FormField control={addressForm.control} name="city" render={({ field }) => (
                            <FormItem><FormLabel>City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={addressForm.control} name="state" render={({ field }) => (
                            <FormItem><FormLabel>State</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={addressForm.control} name="pincode" render={({ field }) => (
                            <FormItem><FormLabel>Pincode</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                          <FormField control={addressForm.control} name="country" render={({ field }) => (
                            <FormItem><FormLabel>Country</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                          )}/>
                        </div>
                        <FormField control={addressForm.control} name="isDefault" render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 mt-2 bg-muted/30">
                            <FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Set as default delivery address</FormLabel>
                            </div>
                          </FormItem>
                        )}/>
                        <Button type="submit" className="w-full mt-4" disabled={addAddressMutation.isPending || updateAddressMutation.isPending}>
                          {editingAddressId ? "Update Address" : "Save Address"}
                        </Button>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              {addrLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6"><Skeleton className="h-40" /><Skeleton className="h-40" /></div>
              ) : addressData?.addresses?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {addressData.addresses.map((addr) => (
                    <Card key={addr._id} className={`border-2 ${addr.isDefault ? 'border-primary' : 'border-border'}`}>
                      <CardHeader className="pb-2 flex flex-row items-start justify-between space-y-0">
                        <CardTitle className="text-base font-bold flex items-center gap-2">
                          {addr.fullName}
                          {addr.isDefault && <span className="bg-accent text-accent-foreground text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">Default</span>}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="text-sm text-muted-foreground space-y-1">
                        <p>{addr.address}</p>
                        <p>{addr.city}, {addr.state} {addr.pincode}</p>
                        <p>{addr.country}</p>
                        <p className="pt-2 flex items-center gap-2 text-foreground"><MapPin className="h-4 w-4 text-primary" /> {addr.mobile}</p>
                      </CardContent>
                      <CardFooter className="bg-muted/30 pt-4 flex gap-2 justify-end border-t">
                        <Button variant="outline" size="sm" onClick={() => handleEditAddress(addr)}>
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </Button>
                        <Button variant="ghost" size="sm" className="text-destructive hover:bg-destructive/10" onClick={() => deleteAddressMutation.mutate({ id: addr._id })}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 bg-muted/30 rounded-xl border border-dashed">
                  <MapPin className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                  <h3 className="font-serif text-xl font-bold mb-2">No saved addresses</h3>
                  <p className="text-muted-foreground mb-6">Add an address to speed up your checkout process.</p>
                  <Button onClick={handleAddAddressClick}>Add Your First Address</Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
