import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useGetCart, useGetAddresses, usePlaceOrder, getGetCartQueryKey, getGetMyOrdersQueryKey, getGetDashboardQueryKey } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { MapPin, CreditCard, Wallet, Plus, CheckCircle2 } from "lucide-react";

export function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedAddress, setSelectedAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Online");

  const { data: cartData, isLoading: cartLoading } = useGetCart({
    query: { queryKey: getGetCartQueryKey() }
  });

  const { data: addressData, isLoading: addrLoading } = useGetAddresses({
    query: { queryKey: ["addresses"] }
  });

  const placeOrderMutation = usePlaceOrder({
    mutation: {
      onSuccess: () => {
        toast({ title: "Order placed successfully!", description: "Thank you for shopping with BookHaven." });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMyOrdersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        setLocation("/orders");
      },
      onError: (err) => {
        toast({ variant: "destructive", title: "Failed to place order", description: err.message || "An error occurred." });
      }
    }
  });

  const items = cartData?.cart?.items || [];
  const subtotal = items.reduce((sum, item) => {
    const price = item.book.discount ? item.book.price * (1 - item.book.discount / 100) : item.book.price;
    return sum + (price * item.quantity);
  }, 0);

  const addresses = addressData?.addresses || [];
  
  // Auto-select default address if available
  useState(() => {
    if (addresses.length > 0 && !selectedAddress) {
      const defaultAddr = addresses.find(a => a.isDefault);
      if (defaultAddr) setSelectedAddress(defaultAddr._id);
      else setSelectedAddress(addresses[0]._id);
    }
  }, [addresses]);

  const handlePlaceOrder = () => {
    if (!selectedAddress) {
      return toast({ variant: "destructive", title: "Address required", description: "Please select a delivery address." });
    }
    placeOrderMutation.mutate({ data: { addressId: selectedAddress, paymentMethod } });
  };

  if (cartLoading || addrLoading) {
    return <div className="container mx-auto p-12"><Skeleton className="h-[60vh] w-full" /></div>;
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center min-h-[calc(100vh-16rem)] flex flex-col justify-center items-center">
        <CheckCircle2 className="h-16 w-16 text-primary mb-4" />
        <h2 className="text-3xl font-serif font-bold mb-4">No items to checkout</h2>
        <Button onClick={() => setLocation("/books")}>Browse Books</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)] bg-background">
      <h1 className="font-serif text-3xl md:text-4xl font-bold mb-8">Checkout</h1>
      
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3 space-y-8">
          {/* Delivery Address */}
          <Card className="border-primary/10 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-serif text-2xl">
                <MapPin className="h-6 w-6 text-primary" /> Delivery Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              {addresses.length > 0 ? (
                <RadioGroup value={selectedAddress} onValueChange={setSelectedAddress} className="space-y-4">
                  {addresses.map(addr => (
                    <div key={addr._id} className={`flex items-start space-x-3 p-4 rounded-lg border-2 transition-colors ${selectedAddress === addr._id ? 'border-primary bg-primary/5' : 'border-transparent bg-muted/30 hover:border-primary/30'}`}>
                      <RadioGroupItem value={addr._id} id={addr._id} className="mt-1" />
                      <Label htmlFor={addr._id} className="cursor-pointer flex-1">
                        <div className="font-bold flex items-center gap-2 text-base">
                          {addr.fullName}
                          {addr.isDefault && <span className="bg-accent text-accent-foreground text-xs px-2 py-0.5 rounded-full font-medium">Default</span>}
                        </div>
                        <div className="text-muted-foreground mt-1 text-sm leading-relaxed">
                          {addr.address}, {addr.city}<br/>
                          {addr.state}, {addr.pincode}<br/>
                          Mobile: {addr.mobile}
                        </div>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              ) : (
                <div className="text-center py-6 bg-muted/30 rounded-lg">
                  <p className="text-muted-foreground mb-4">No addresses found.</p>
                  <Button variant="outline" onClick={() => setLocation("/profile")}>
                    <Plus className="h-4 w-4 mr-2" /> Add New Address
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card className="border-primary/10 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-serif text-2xl">
                <Wallet className="h-6 w-6 text-primary" /> Payment Method
              </CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                <div className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-colors ${paymentMethod === 'Online' ? 'border-primary bg-primary/5' : 'border-transparent bg-muted/30 hover:border-primary/30'}`}>
                  <RadioGroupItem value="Online" id="online" />
                  <Label htmlFor="online" className="cursor-pointer flex-1 flex items-center gap-2 font-medium text-base">
                    <CreditCard className="h-5 w-5 text-muted-foreground" /> Credit/Debit Card or UPI
                  </Label>
                </div>
                <div className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-colors ${paymentMethod === 'COD' ? 'border-primary bg-primary/5' : 'border-transparent bg-muted/30 hover:border-primary/30'}`}>
                  <RadioGroupItem value="COD" id="cod" />
                  <Label htmlFor="cod" className="cursor-pointer flex-1 font-medium text-base">
                    Cash on Delivery (COD)
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary */}
        <div className="lg:w-1/3">
          <Card className="sticky top-24 border-primary/20 shadow-md">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle className="font-serif text-2xl">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-2">
                {items.map(item => {
                  const price = item.book.discount ? item.book.price * (1 - item.book.discount / 100) : item.book.price;
                  return (
                    <div key={item._id} className="flex gap-4">
                      <div className="w-16 h-24 shrink-0 rounded overflow-hidden bg-muted border">
                        <img src={item.book.coverImage} alt={item.book.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 text-sm">
                        <h4 className="font-bold line-clamp-2">{item.book.title}</h4>
                        <p className="text-muted-foreground mt-1">Qty: {item.quantity}</p>
                        <p className="font-bold text-primary mt-1">${(price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="border-t mt-6 pt-6 space-y-3 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span className="font-medium text-foreground">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span className="font-medium text-foreground">Free</span>
                </div>
                <div className="border-t pt-3 flex justify-between items-end mt-2">
                  <span className="font-bold text-lg">Total</span>
                  <span className="font-bold text-3xl text-primary">${subtotal.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-muted/10 pb-6 pt-0 border-t mt-4 border-dashed">
              <Button 
                className="w-full h-14 text-lg rounded-full shadow-lg mt-6" 
                onClick={handlePlaceOrder}
                disabled={placeOrderMutation.isPending || !selectedAddress}
              >
                {placeOrderMutation.isPending ? "Placing Order..." : "Place Order"}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
