import { useSearchBooks, getSearchBooksQueryKey } from "@/lib/apiClient";
import { BookCard } from "@/components/BookCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Search as SearchIcon } from "lucide-react";

export function Search() {
  const searchParams = new URLSearchParams(window.location.search);
  const keyword = searchParams.get("keyword") || "";

  const { data, isLoading } = useSearchBooks({ keyword }, {
    query: { enabled: !!keyword, queryKey: getSearchBooksQueryKey({ keyword }) }
  });

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-bold text-foreground">
          Search Results
        </h1>
        <p className="text-muted-foreground mt-2">
          {keyword ? `Showing results for "${keyword}"` : "Please enter a search term"}
        </p>
      </div>

      {!keyword ? (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-muted/30 rounded-2xl border border-dashed">
          <SearchIcon className="h-12 w-12 text-muted-foreground/30 mb-4" />
          <h3 className="font-serif text-xl font-bold mb-2">Search BookHaven</h3>
          <p className="text-muted-foreground">Type something in the search bar above to find books, authors, or genres.</p>
        </div>
      ) : isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex flex-col gap-3">
              <Skeleton className="aspect-[2/3] w-full rounded-xl" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))}
        </div>
      ) : data?.books?.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
          {data.books.map(book => (
            <BookCard key={book._id} book={book} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-muted/30 rounded-2xl border border-dashed">
          <SearchIcon className="h-16 w-16 text-muted-foreground/50 mb-4" />
          <h3 className="font-serif text-2xl font-bold mb-2">No results found</h3>
          <p className="text-muted-foreground max-w-md">
            We couldn't find any books matching "{keyword}". Try checking your spelling or using more general terms.
          </p>
        </div>
      )}
    </div>
  );
}
