import { useGetWishlist, useRemoveFromWishlist, useAddToCart, getGetWishlistQueryKey, getGetDashboardQueryKey, getGetCartQueryKey } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Heart, Trash2, ShoppingCart } from "lucide-react";

export function Wishlist() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: wishlistData, isLoading } = useGetWishlist({
    query: { queryKey: getGetWishlistQueryKey() }
  });

  const removeMutation = useRemoveFromWishlist({
    mutation: {
      onSuccess: () => {
        toast({ title: "Removed from wishlist" });
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      }
    }
  });

  const addToCartMutation = useAddToCart({
    mutation: {
      onSuccess: () => {
        toast({ title: "Added to cart" });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      }
    }
  });

  const handleRemove = (e, bookId) => {
    e.preventDefault();
    e.stopPropagation();
    removeMutation.mutate({ bookId });
  };

  const handleAddToCart = (e, bookId) => {
    e.preventDefault();
    e.stopPropagation();
    addToCartMutation.mutate({ data: { bookId, quantity: 1 } });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
        <h1 className="font-serif text-3xl font-bold mb-8">My Wishlist</h1>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} className="aspect-[2/3] w-full rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  const books = wishlistData?.wishlist?.books || [];

  if (books.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center text-center">
        <div className="h-24 w-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <Heart className="h-12 w-12 text-muted-foreground" />
        </div>
        <h2 className="font-serif text-3xl font-bold mb-4">Your wishlist is empty</h2>
        <p className="text-muted-foreground max-w-md mb-8">
          Keep track of books you want to read. Add them to your wishlist to easily find them later.
        </p>
        <Link href="/books">
          <Button size="lg" className="rounded-full px-8">Browse Books</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground">My Wishlist</h1>
        <span className="text-muted-foreground">{books.length} {books.length === 1 ? 'item' : 'items'}</span>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
        {books.map((book) => {
          const hasDiscount = book.discount && book.discount > 0;
          const discountedPrice = hasDiscount ? book.price * (1 - book.discount / 100) : book.price;

          return (
            <Link key={book._id} href={`/books/${book._id}`}>
              <div className="group relative flex flex-col h-full bg-card rounded-xl border overflow-hidden book-card-hover cursor-pointer">
                <div className="relative aspect-[2/3] w-full overflow-hidden bg-muted">
                  <img 
                    src={book.coverImage} 
                    alt={book.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute top-2 right-2">
                    <Button 
                      size="icon" 
                      variant="secondary" 
                      className="h-8 w-8 rounded-full shadow-md bg-white hover:bg-destructive text-destructive hover:text-white transition-colors"
                      onClick={(e) => handleRemove(e, book._id)}
                      disabled={removeMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="p-4 flex flex-col flex-grow">
                  <h3 className="font-serif font-bold text-lg leading-tight mb-1 line-clamp-2 text-foreground">
                    {book.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-1">
                    {book.author?.name}
                  </p>
                  
                  <div className="mt-auto pt-2 flex items-center justify-between gap-2">
                    <div className="flex flex-col">
                      {hasDiscount ? (
                        <>
                          <span className="text-[10px] text-muted-foreground line-through">${book.price.toFixed(2)}</span>
                          <span className="font-bold text-primary">${discountedPrice.toFixed(2)}</span>
                        </>
                      ) : (
                        <span className="font-bold text-primary">${book.price.toFixed(2)}</span>
                      )}
                    </div>
                    <Button 
                      size="sm" 
                      className="rounded-full shadow-sm bg-primary hover:bg-primary/90 shrink-0"
                      onClick={(e) => handleAddToCart(e, book._id)}
                      disabled={addToCartMutation.isPending}
                    >
                      <ShoppingCart className="h-4 w-4 md:mr-2" />
                      <span className="hidden md:inline">Add</span>
                    </Button>
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
