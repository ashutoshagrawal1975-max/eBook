import { useGetCart, useUpdateCartItem, useRemoveCartItem, getGetCartQueryKey, getGetDashboardQueryKey } from "@/lib/apiClient";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";

export function Cart() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cartData, isLoading } = useGetCart({
    query: { queryKey: getGetCartQueryKey() }
  });

  const updateMutation = useUpdateCartItem({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      }
    }
  });

  const removeMutation = useRemoveCartItem({
    mutation: {
      onSuccess: () => {
        toast({ title: "Item removed", description: "The item has been removed from your cart." });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      }
    }
  });

  const handleUpdateQuantity = (itemId, currentQuantity, change) => {
    const newQuantity = currentQuantity + change;
    if (newQuantity < 1) return;
    updateMutation.mutate({ itemId, data: { quantity: newQuantity } });
  };

  const handleRemove = (itemId) => {
    removeMutation.mutate({ itemId });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
        <h1 className="font-serif text-3xl font-bold mb-8">Your Cart</h1>
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/3 space-y-4">
            {[1, 2].map(i => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
          </div>
          <div className="lg:w-1/3">
            <Skeleton className="h-64 w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  const items = cartData?.cart?.items || [];
  const subtotal = items.reduce((sum, item) => {
    const price = item.book.discount ? item.book.price * (1 - item.book.discount / 100) : item.book.price;
    return sum + (price * item.quantity);
  }, 0);

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center text-center">
        <div className="h-24 w-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <ShoppingBag className="h-12 w-12 text-muted-foreground" />
        </div>
        <h2 className="font-serif text-3xl font-bold mb-4">Your cart is empty</h2>
        <p className="text-muted-foreground max-w-md mb-8">
          Looks like you haven't added any books to your cart yet. Discover your next favorite read in our collection.
        </p>
        <Link href="/books">
          <Button size="lg" className="rounded-full px-8">Continue Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
      <h1 className="font-serif text-3xl md:text-4xl font-bold mb-8 text-foreground">Your Cart</h1>
      
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
        <div className="lg:w-2/3">
          <div className="bg-card border rounded-2xl overflow-hidden">
            <div className="hidden md:grid grid-cols-12 gap-4 p-4 border-b bg-muted/30 text-sm font-medium text-muted-foreground">
              <div className="col-span-6">Book</div>
              <div className="col-span-2 text-center">Price</div>
              <div className="col-span-2 text-center">Quantity</div>
              <div className="col-span-2 text-right">Total</div>
            </div>
            
            <div className="divide-y">
              {items.map((item) => {
                const book = item.book;
                const price = book.discount ? book.price * (1 - book.discount / 100) : book.price;
                const total = price * item.quantity;
                
                return (
                  <div key={item._id} className="p-4 sm:p-6 flex flex-col sm:grid sm:grid-cols-12 gap-4 items-center">
                    <div className="col-span-12 sm:col-span-6 flex gap-4 w-full">
                      <Link href={`/books/${book._id}`}>
                        <div className="w-20 sm:w-24 shrink-0 rounded-md overflow-hidden bg-muted aspect-[2/3] cursor-pointer">
                          <img src={book.coverImage} alt={book.title} className="w-full h-full object-cover" />
                        </div>
                      </Link>
                      <div className="flex flex-col flex-1 py-1">
                        <Link href={`/books/${book._id}`}>
                          <h3 className="font-serif font-bold text-lg leading-tight hover:text-primary cursor-pointer line-clamp-2">{book.title}</h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mb-2">{book.author?.name}</p>
                        
                        {/* Mobile Price & Quantity */}
                        <div className="mt-auto sm:hidden flex items-center justify-between w-full">
                          <div className="font-bold">${price.toFixed(2)}</div>
                          <div className="flex items-center gap-2 bg-muted rounded-full p-1 border">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6 rounded-full" 
                              onClick={() => handleUpdateQuantity(item._id, item.quantity, -1)}
                              disabled={updateMutation.isPending}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6 rounded-full" 
                              onClick={() => handleUpdateQuantity(item._id, item.quantity, 1)}
                              disabled={updateMutation.isPending}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Desktop Price */}
                    <div className="hidden sm:block col-span-2 text-center font-medium">
                      ${price.toFixed(2)}
                    </div>
                    
                    {/* Desktop Quantity */}
                    <div className="hidden sm:flex col-span-2 justify-center items-center">
                      <div className="flex items-center gap-1 bg-muted rounded-full p-1 border">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 rounded-full" 
                          onClick={() => handleUpdateQuantity(item._id, item.quantity, -1)}
                          disabled={updateMutation.isPending}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 rounded-full" 
                          onClick={() => handleUpdateQuantity(item._id, item.quantity, 1)}
                          disabled={updateMutation.isPending}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Desktop Total & Remove */}
                    <div className="hidden sm:flex col-span-2 justify-end items-center gap-4">
                      <span className="font-bold text-lg">${total.toFixed(2)}</span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={() => handleRemove(item._id)}
                        disabled={removeMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* Mobile Remove & Total */}
                    <div className="sm:hidden w-full flex justify-between items-center pt-3 border-t mt-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-muted-foreground hover:text-destructive h-8 px-2"
                        onClick={() => handleRemove(item._id)}
                        disabled={removeMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4 mr-2" /> Remove
                      </Button>
                      <span className="font-bold text-lg">Total: ${total.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        
        <div className="lg:w-1/3">
          <div className="bg-muted/30 border rounded-2xl p-6 sticky top-24">
            <h3 className="font-serif text-2xl font-bold mb-6">Order Summary</h3>
            
            <div className="space-y-4 mb-6 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal ({items.length} items)</span>
                <span className="font-medium">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span className="font-medium">Calculated at checkout</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Taxes</span>
                <span className="font-medium">Calculated at checkout</span>
              </div>
            </div>
            
            <div className="border-t pt-4 mb-8">
              <div className="flex justify-between items-end">
                <span className="font-bold text-lg">Estimated Total</span>
                <span className="font-bold text-2xl text-primary">${subtotal.toFixed(2)}</span>
              </div>
            </div>
            
            <Button 
              className="w-full h-12 text-base rounded-full" 
              onClick={() => setLocation("/checkout")}
            >
              Proceed to Checkout <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            
            <div className="mt-6 text-center">
              <Link href="/books" className="text-sm text-primary hover:underline font-medium flex items-center justify-center">
                <ArrowRight className="mr-2 h-4 w-4 rotate-180" /> Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
