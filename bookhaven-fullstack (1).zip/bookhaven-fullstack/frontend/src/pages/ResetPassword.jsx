import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ShieldAlert } from "lucide-react";

import { useResetPassword } from "@/lib/apiClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

const resetSchema = z.object({
  otp: z.string().length(6, "OTP must be exactly 6 characters"),
  password: z.string().min(6, "New password must be at least 6 characters"),
});

export function ResetPassword() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [email, setEmail] = useState("");
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const emailParam = params.get("email");
    if (emailParam) {
      setEmail(emailParam);
    } else {
      toast({ title: "Error", description: "Email not found in URL. Redirecting...", variant: "destructive" });
      setLocation("/forgot-password");
    }
  }, [setLocation, toast]);
  
  const form = useForm({
    resolver: zodResolver(resetSchema),
    defaultValues: { otp: "", password: "" },
  });

  const resetMutation = useResetPassword({
    mutation: {
      onSuccess: (data) => {
        if (data.success) {
          toast({ title: "Password Reset", description: "Your password has been changed. You can now log in." });
          setLocation("/login");
        } else {
          toast({ variant: "destructive", title: "Reset failed", description: data.message || "Invalid OTP." });
        }
      },
      onError: (error) => {
        toast({
          variant: "destructive",
          title: "Reset failed",
          description: error.message || "Something went wrong.",
        });
      },
    },
  });

  const onSubmit = (data) => {
    resetMutation.mutate({ data: { email, otp: data.otp, password: data.password } });
  };

  return (
    <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[calc(100vh-16rem)]">
      <Card className="w-full max-w-md shadow-lg border-primary/10">
        <CardHeader className="space-y-3 text-center pt-8">
          <div className="flex justify-center mb-2">
            <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <ShieldAlert className="h-6 w-6" />
            </div>
          </div>
          <CardTitle className="font-serif text-3xl font-bold">Reset Password</CardTitle>
          <CardDescription>Enter the code sent to {email || "your email"} and your new password</CardDescription>
        </CardHeader>
        <CardContent className="pb-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 flex flex-col items-center">
              <FormField
                control={form.control}
                name="otp"
                render={({ field }) => (
                  <FormItem className="flex flex-col items-center justify-center text-center w-full">
                    <FormLabel className="mb-2 w-full text-left">Verification Code</FormLabel>
                    <FormControl>
                      <InputOTP maxLength={6} {...field}>
                        <InputOTPGroup>
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                          <InputOTPSlot index={5} />
                        </InputOTPGroup>
                      </InputOTP>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full h-11 text-base mt-4" disabled={resetMutation.isPending || !email}>
                {resetMutation.isPending ? "Resetting..." : "Reset Password"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
