import { useGetBooks, getGetBooksQueryKey, useGetCategories, getGetCategoriesQueryKey } from "@/lib/apiClient";
import { useLocation } from "wouter";
import { BookCard } from "@/components/BookCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { BookX } from "lucide-react";

export function Books() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const categoryParam = searchParams.get("category");
  const bestSellerParam = searchParams.get("bestSeller");

  const [page, setPage] = useState(1);
  const limit = 20; // 20 per page

  // Currently the API doesn't fully support filtering by bestSeller via getBooks params except what's on GetBooksParams
  // Let's use standard fetching. If we need specific filtered views that aren't supported via query params, we might just fetch all and filter client side if needed, or rely on the endpoints.
  // Actually, getBooks endpoint probably handles query params like ?category=id. We will fetch and if it doesn't, we can use useGetBooksByCategory.
  
  // To keep it simple, we'll fetch all books and client-side filter if the API doesn't support it directly in params, 
  // or use the specific hooks. Let's use specific hooks if category is selected, but getBooks doesn't accept category.
  
  const { data: booksData, isLoading: booksLoading } = useGetBooks(
    { page, limit },
    { query: { queryKey: getGetBooksQueryKey({ page, limit }) } }
  );

  const { data: categoriesData } = useGetCategories({
    query: { queryKey: getGetCategoriesQueryKey() }
  });

  // Client side filtering for demo purposes since the API schemas for GetBooksParams only show page and limit
  let displayedBooks = booksData?.books || [];
  
  if (categoryParam) {
    displayedBooks = displayedBooks.filter(b => b.genre?.toLowerCase() === categoryParam.toLowerCase());
  } else if (bestSellerParam === "true") {
    displayedBooks = displayedBooks.filter(b => b.bestSeller);
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-baseline justify-between mb-8 gap-4">
        <div>
          <h1 className="font-serif text-4xl font-bold text-foreground">
            {categoryParam ? `${categoryParam} Books` : bestSellerParam ? "Bestsellers" : "All Books"}
          </h1>
          <p className="text-muted-foreground mt-2">Explore our extensive collection</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar filters */}
        <aside className="w-full md:w-64 flex-shrink-0">
          <div className="sticky top-24 space-y-6">
            <div>
              <h3 className="font-serif font-bold text-lg mb-4 pb-2 border-b">Categories</h3>
              <div className="space-y-2">
                <a href="/books" className={`block text-sm py-1 hover:text-primary ${!categoryParam ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                  All Categories
                </a>
                {categoriesData?.categories?.map(cat => (
                  <a 
                    key={cat._id} 
                    href={`/books?category=${encodeURIComponent(cat.name)}`} 
                    className={`block text-sm py-1 hover:text-primary ${categoryParam === cat.name ? 'text-primary font-bold' : 'text-muted-foreground'}`}
                  >
                    {cat.name}
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-serif font-bold text-lg mb-4 pb-2 border-b">Collections</h3>
              <div className="space-y-2">
                <a href="/books?bestSeller=true" className={`block text-sm py-1 hover:text-primary ${bestSellerParam === 'true' ? 'text-primary font-bold' : 'text-muted-foreground'}`}>
                  Bestsellers
                </a>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          {booksLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="flex flex-col gap-3">
                  <Skeleton className="aspect-[2/3] w-full rounded-xl" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-6 w-full" />
                </div>
              ))}
            </div>
          ) : displayedBooks.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {displayedBooks.map(book => (
                <BookCard key={book._id} book={book} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center bg-muted/30 rounded-2xl border border-dashed">
              <BookX className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <h3 className="font-serif text-2xl font-bold mb-2">No books found</h3>
              <p className="text-muted-foreground max-w-md">
                We couldn't find any books matching your current filters. Try selecting a different category.
              </p>
              <Button asChild className="mt-6">
                <a href="/books">Clear Filters</a>
              </Button>
            </div>
          )}

          {/* Basic Pagination - only if we have full unfiltered data or API supports it */}
          {!categoryParam && !bestSellerParam && displayedBooks.length > 0 && booksData?.count > limit && (
            <div className="flex justify-center mt-12 gap-2">
              <Button 
                variant="outline" 
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
              >
                Previous
              </Button>
              <span className="flex items-center px-4 font-medium text-sm">
                Page {page} of {Math.ceil(booksData.count / limit)}
              </span>
              <Button 
                variant="outline" 
                disabled={page >= Math.ceil(booksData.count / limit)}
                onClick={() => setPage(p => p + 1)}
              >
                Next
              </Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
