import { useParams, Link } from "wouter";
import { useGetBook, getGetBookQueryKey, useGetRelatedBooks, useGetBookReviews, useAddToCart, useAddToWishlist, useAddReview, getGetDashboardQueryKey, getGetCartQueryKey, getGetWishlistQueryKey, getGetBookReviewsQueryKey } from "@/lib/apiClient";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Star, ShoppingCart, Heart, BookOpen, Globe, User as UserIcon, Calendar, MessageSquare } from "lucide-react";
import { BookCard } from "@/components/BookCard";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";

export function BookDetail() {
  const params = useParams();
  const id = params.id;
  
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const { data: bookData, isLoading: bookLoading } = useGetBook(id, {
    query: { enabled: !!id, queryKey: getGetBookQueryKey(id) }
  });
  
  const { data: relatedData } = useGetRelatedBooks(id, {
    query: { enabled: !!id, queryKey: ["related-books", id] }
  });
  
  const { data: reviewsData } = useGetBookReviews(id, {
    query: { enabled: !!id, queryKey: getGetBookReviewsQueryKey(id) }
  });

  const addToCartMutation = useAddToCart({
    mutation: {
      onSuccess: () => {
        toast({ title: "Added to cart", description: "Item added to your cart." });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
      }
    }
  });

  const addToWishlistMutation = useAddToWishlist({
    mutation: {
      onSuccess: () => {
        toast({ title: "Saved to wishlist", description: "Item added to your wishlist." });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
      }
    }
  });

  const addReviewMutation = useAddReview({
    mutation: {
      onSuccess: () => {
        toast({ title: "Review submitted", description: "Thank you for your review." });
        setComment("");
        setRating(5);
        queryClient.invalidateQueries({ queryKey: getGetBookReviewsQueryKey(id) });
      }
    }
  });

  const handleAddToCart = () => {
    if (!isAuthenticated) return toast({ title: "Please log in" });
    addToCartMutation.mutate({ data: { bookId: id, quantity: 1 } });
  };

  const handleAddToWishlist = () => {
    if (!isAuthenticated) return toast({ title: "Please log in" });
    addToWishlistMutation.mutate({ data: { bookId: id } });
  };

  const submitReview = (e) => {
    e.preventDefault();
    if (!isAuthenticated) return toast({ title: "Please log in" });
    addReviewMutation.mutate({ data: { bookId: id, rating, comment } });
  };

  if (bookLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          <Skeleton className="w-full md:w-1/3 aspect-[2/3] rounded-xl" />
          <div className="w-full md:w-2/3 space-y-6">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-32 w-full" />
            <div className="flex gap-4">
              <Skeleton className="h-12 w-40" />
              <Skeleton className="h-12 w-12" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  const book = bookData?.book;
  if (!book) return <div className="container mx-auto py-20 text-center"><h2 className="text-2xl font-bold">Book not found</h2></div>;

  const hasDiscount = book.discount && book.discount > 0;
  const discountedPrice = hasDiscount ? book.price * (1 - book.discount / 100) : book.price;

  return (
    <div className="container mx-auto px-4 py-8 md:py-12">
      {/* Book details hero */}
      <div className="flex flex-col md:flex-row gap-8 lg:gap-16 mb-16">
        <div className="w-full md:w-1/3 lg:w-1/4 shrink-0">
          <div className="sticky top-24 bg-card border rounded-2xl overflow-hidden shadow-sm">
            <img 
              src={book.coverImage || "https://placehold.co/600x900/f8f5f0/1b2a4a?text=Cover"} 
              alt={book.title} 
              className="w-full h-auto object-cover aspect-[2/3]"
            />
            {hasDiscount && (
              <div className="absolute top-4 left-4 bg-destructive text-destructive-foreground font-bold px-3 py-1 rounded-md shadow-lg">
                Save {book.discount}%
              </div>
            )}
          </div>
        </div>

        <div className="w-full md:w-2/3 lg:w-3/4 flex flex-col">
          <div className="mb-2 text-accent font-semibold tracking-wider uppercase text-sm">
            {book.genre}
          </div>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-4">
            {book.title}
          </h1>
          
          <div className="flex items-center gap-2 mb-6">
            <span className="text-muted-foreground">by</span>
            <Link href={`/authors/${book.author?._id}`}>
              <span className="font-medium text-primary hover:underline text-lg cursor-pointer">
                {book.author?.name || "Unknown Author"}
              </span>
            </Link>
          </div>

          <div className="flex items-center gap-4 mb-8 pb-8 border-b">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`h-5 w-5 ${i < Math.round(book.ratings?.average || 0) ? "fill-accent text-accent" : "text-muted"}`} />
              ))}
              <span className="ml-2 text-sm font-medium">{book.ratings?.average?.toFixed(1) || "No ratings"}</span>
              <span className="ml-1 text-sm text-muted-foreground">({book.ratings?.count || 0} reviews)</span>
            </div>
          </div>

          <div className="mb-8">
            <div className="flex items-end gap-4 mb-6">
              {hasDiscount ? (
                <>
                  <span className="text-4xl font-bold text-primary">${discountedPrice.toFixed(2)}</span>
                  <span className="text-xl text-muted-foreground line-through mb-1">${book.price.toFixed(2)}</span>
                </>
              ) : (
                <span className="text-4xl font-bold text-primary">${book.price.toFixed(2)}</span>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="flex-1 rounded-full text-base h-14" onClick={handleAddToCart} disabled={addToCartMutation.isPending}>
                <ShoppingCart className="mr-2 h-5 w-5" /> Add to Cart
              </Button>
              <Button size="lg" variant="outline" className="rounded-full text-base h-14" onClick={handleAddToWishlist} disabled={addToWishlistMutation.isPending}>
                <Heart className="mr-2 h-5 w-5 text-destructive" /> Save to Wishlist
              </Button>
            </div>
          </div>

          <div className="mb-10">
            <h3 className="font-serif text-2xl font-bold mb-4">Synopsis</h3>
            <div className="prose prose-slate max-w-none text-muted-foreground leading-relaxed">
              <p>{book.description || "No description available."}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-6 bg-muted/40 rounded-2xl border">
            <div className="flex flex-col gap-1">
              <span className="text-xs text-muted-foreground flex items-center gap-1"><BookOpen className="h-3 w-3"/> Pages</span>
              <span className="font-medium">{book.pages || "N/A"}</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs text-muted-foreground flex items-center gap-1"><Globe className="h-3 w-3"/> Language</span>
              <span className="font-medium">{book.language || "English"}</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3"/> Published</span>
              <span className="font-medium">2023</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs text-muted-foreground flex items-center gap-1"><UserIcon className="h-3 w-3"/> Publisher</span>
              <span className="font-medium">{book.publisher || "BookHaven Press"}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="border-t pt-12 mb-16">
        <h2 className="font-serif text-3xl font-bold mb-8">Reader Reviews</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1">
            <div className="bg-card p-6 rounded-2xl border sticky top-24">
              <h3 className="font-bold text-lg mb-4">Write a Review</h3>
              {isAuthenticated ? (
                <form onSubmit={submitReview} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Rating</label>
                    <div className="flex gap-2">
                      {[1,2,3,4,5].map(star => (
                        <Star 
                          key={star} 
                          className={`h-6 w-6 cursor-pointer ${rating >= star ? "fill-accent text-accent" : "text-muted hover:text-accent"}`}
                          onClick={() => setRating(star)}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Your Review</label>
                    <Textarea 
                      placeholder="What did you think of this book?" 
                      className="resize-none h-24"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={addReviewMutation.isPending}>
                    Submit Review
                  </Button>
                </form>
              ) : (
                <div className="text-center p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground mb-4">Please log in to share your thoughts.</p>
                  <Link href="/login">
                    <Button variant="outline" className="w-full">Log In</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
          
          <div className="md:col-span-2 space-y-6">
            {reviewsData?.reviews?.length > 0 ? (
              reviewsData.reviews.map(review => (
                <div key={review._id} className="p-6 rounded-2xl bg-muted/20 border">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">
                        {review.user?.name?.charAt(0) || "U"}
                      </div>
                      <div>
                        <div className="font-medium">{review.user?.name || "Anonymous User"}</div>
                        <div className="text-xs text-muted-foreground">{new Date(review.createdAt || Date.now()).toLocaleDateString()}</div>
                      </div>
                    </div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-4 w-4 ${i < review.rating ? "fill-accent text-accent" : "text-muted"}`} />
                      ))}
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">{review.comment || "No comment provided."}</p>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center bg-muted/10 rounded-2xl border border-dashed h-full">
                <MessageSquare className="h-12 w-12 text-muted-foreground/30 mb-4" />
                <h3 className="font-serif text-xl font-bold mb-2">No reviews yet</h3>
                <p className="text-muted-foreground">Be the first to review this book!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Related Books */}
      {relatedData?.books?.length > 0 && (
        <div className="border-t pt-12">
          <h2 className="font-serif text-3xl font-bold mb-8">You might also like</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
            {relatedData.books.slice(0, 5).map(relatedBook => (
              <BookCard key={relatedBook._id} book={relatedBook} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
