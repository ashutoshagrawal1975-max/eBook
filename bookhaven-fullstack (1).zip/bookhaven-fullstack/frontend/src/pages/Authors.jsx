import { useGetAuthors, getGetAuthorsQueryKey } from "@/lib/apiClient";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { UserCircle } from "lucide-react";

export function Authors() {
  const { data, isLoading } = useGetAuthors({
    query: { queryKey: getGetAuthorsQueryKey() }
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto text-center mb-16">
        <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">Meet the Authors</h1>
        <p className="text-lg text-muted-foreground">Discover the brilliant minds behind your favorite stories.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex flex-col items-center text-center">
              <Skeleton className="w-32 h-32 rounded-full mb-4" />
              <Skeleton className="h-5 w-24 mb-2" />
              <Skeleton className="h-4 w-16" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-6 gap-y-12">
          {data?.authors?.map((author) => (
            <Link key={author._id} href={`/authors/${author._id}`}>
              <div className="group flex flex-col items-center text-center cursor-pointer">
                <div className="w-32 h-32 rounded-full overflow-hidden mb-4 border-4 border-transparent group-hover:border-accent transition-all duration-300 relative shadow-sm">
                  {author.image ? (
                    <img src={author.image} alt={author.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-muted flex items-center justify-center">
                      <UserCircle className="w-12 h-12 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <h3 className="font-serif font-bold text-lg group-hover:text-primary transition-colors">{author.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{author.booksCount || 0} Published Books</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
