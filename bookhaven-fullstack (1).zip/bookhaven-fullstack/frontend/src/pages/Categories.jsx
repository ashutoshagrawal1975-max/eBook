import { useGetCategories, getGetCategoriesQueryKey } from "@/lib/apiClient";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen } from "lucide-react";

export function Categories() {
  const { data, isLoading } = useGetCategories({
    query: { queryKey: getGetCategoriesQueryKey() }
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto text-center mb-16">
        <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">Explore by Genre</h1>
        <p className="text-lg text-muted-foreground">Find your next favorite story within our curated collections.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-40 w-full rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {data?.categories?.map((cat) => (
            <Link key={cat._id} href={`/books?category=${encodeURIComponent(cat.name)}`}>
              <div className="group relative overflow-hidden rounded-2xl aspect-video cursor-pointer border bg-muted flex flex-col items-center justify-center p-6 text-center hover:border-primary/50 transition-colors">
                <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                {cat.image ? (
                  <img src={cat.image} alt={cat.name} className="absolute inset-0 w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity mix-blend-multiply" />
                ) : (
                  <BookOpen className="h-10 w-10 text-primary/30 mb-3 group-hover:text-primary/50 transition-colors" />
                )}
                <h3 className="relative z-10 font-serif text-xl font-bold text-foreground">{cat.name}</h3>
                {cat.description && (
                  <p className="relative z-10 text-sm text-muted-foreground mt-2 line-clamp-2">{cat.description}</p>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
