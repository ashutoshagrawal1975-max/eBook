import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { KeyRound } from "lucide-react";

import { useForgotPassword } from "@/lib/apiClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";

const forgotSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export function ForgotPassword() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const form = useForm({
    resolver: zodResolver(forgotSchema),
    defaultValues: { email: "" },
  });

  const forgotMutation = useForgotPassword({
    mutation: {
      onSuccess: (data, variables) => {
        if (data.success) {
          toast({ title: "OTP Sent", description: "Check your email for the password reset code." });
          setLocation(`/reset-password?email=${encodeURIComponent(variables.data.email)}`);
        } else {
          toast({ variant: "destructive", title: "Failed to send OTP", description: data.message || "An error occurred." });
        }
      },
      onError: (error) => {
        toast({
          variant: "destructive",
          title: "Failed",
          description: error.message || "Something went wrong.",
        });
      },
    },
  });

  const onSubmit = (data) => {
    forgotMutation.mutate({ data });
  };

  return (
    <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[calc(100vh-16rem)]">
      <Card className="w-full max-w-md shadow-lg border-primary/10">
        <CardHeader className="space-y-3 text-center pt-8">
          <div className="flex justify-center mb-2">
            <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <KeyRound className="h-6 w-6" />
            </div>
          </div>
          <CardTitle className="font-serif text-3xl font-bold">Forgot Password</CardTitle>
          <CardDescription>Enter your email to receive a password reset code</CardDescription>
        </CardHeader>
        <CardContent className="pb-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input placeholder="you@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full h-11 text-base" disabled={forgotMutation.isPending}>
                {forgotMutation.isPending ? "Sending code..." : "Send Reset Code"}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-center border-t py-6 bg-muted/30">
          <p className="text-sm text-muted-foreground">
            Remember your password?{" "}
            <Link href="/login" className="text-primary hover:underline font-semibold">
              Back to login
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
