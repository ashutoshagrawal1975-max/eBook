import { useParams } from "wouter";
import { useGetAuthor, useGetBooksByAuthor, getGetBooksByAuthorQueryKey } from "@/lib/apiClient";
import { Skeleton } from "@/components/ui/skeleton";
import { BookCard } from "@/components/BookCard";
import { UserCircle, MapPin } from "lucide-react";

export function AuthorDetail() {
  const { id } = useParams();

  const { data: authorData, isLoading: authorLoading } = useGetAuthor(id, {
    query: { enabled: !!id, queryKey: ["author", id] }
  });

  const { data: booksData, isLoading: booksLoading } = useGetBooksByAuthor(id, {
    query: { enabled: !!id, queryKey: getGetBooksByAuthorQueryKey(id) }
  });

  if (authorLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16">
          <Skeleton className="w-40 h-40 rounded-full mb-6" />
          <Skeleton className="h-10 w-64 mb-4" />
          <Skeleton className="h-4 w-32 mb-6" />
          <Skeleton className="h-24 w-full" />
        </div>
      </div>
    );
  }

  const author = authorData?.author;
  if (!author) return <div className="container mx-auto py-20 text-center"><h2 className="text-2xl font-bold">Author not found</h2></div>;

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="bg-card border rounded-3xl p-8 md:p-12 mb-16 shadow-sm">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8 max-w-4xl mx-auto">
          <div className="w-40 h-40 shrink-0 rounded-full overflow-hidden border-4 border-background shadow-md">
            {author.image ? (
              <img src={author.image} alt={author.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <UserCircle className="w-16 h-16 text-muted-foreground" />
              </div>
            )}
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-3">{author.name}</h1>
            {author.nationality && (
              <div className="flex items-center justify-center md:justify-start gap-1 text-muted-foreground mb-6">
                <MapPin className="h-4 w-4" />
                <span>{author.nationality}</span>
              </div>
            )}
            <div className="prose prose-slate max-w-none text-muted-foreground leading-relaxed">
              <p>{author.bio || "No biography available for this author."}</p>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h2 className="font-serif text-3xl font-bold mb-8">Books by {author.name}</h2>
        {booksLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="aspect-[2/3] w-full rounded-xl" />
            ))}
          </div>
        ) : booksData?.books?.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
            {booksData.books.map(book => (
              <BookCard key={book._id} book={book} />
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-center py-12">No books found for this author.</p>
        )}
      </div>
    </div>
  );
}
