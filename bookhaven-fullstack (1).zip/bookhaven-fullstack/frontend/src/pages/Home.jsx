import { useGetHomeData } from "@/lib/apiClient";
import { getGetHomeDataQueryKey } from "@/lib/apiClient";
import { BookCard } from "@/components/BookCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, BookOpen, Truck, ShieldCheck, Clock } from "lucide-react";
import useEmblaCarousel from "embla-carousel-react";
import { useEffect } from "react";

function HomeHero({ banners = [] }) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });

  useEffect(() => {
    if (!emblaApi) return;
    const interval = setInterval(() => {
      emblaApi.scrollNext();
    }, 5000);
    return () => clearInterval(interval);
  }, [emblaApi]);

  if (!banners || banners.length === 0) {
    return (
      <div className="relative bg-primary text-primary-foreground py-24 px-6 md:px-12 flex flex-col items-center text-center overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80')] bg-cover bg-center"></div>
        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          <span className="text-accent font-semibold tracking-widest uppercase text-sm">Welcome to BookHaven</span>
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold leading-tight">
            Discover your next great read.
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 max-w-2xl mx-auto">
            A curated collection of premium e-books, waiting to be explored.
          </p>
          <div className="pt-4">
            <Link href="/books">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full px-8 text-base">
                Start Browsing
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden" ref={emblaRef}>
      <div className="flex">
        {banners.map((banner) => (
          <div key={banner._id} className="relative flex-[0_0_100%] min-w-0">
            <div className="relative h-[60vh] min-h-[400px] w-full bg-primary flex items-center">
              <div className="absolute inset-0">
                <img src={banner.image} alt={banner.title} className="w-full h-full object-cover opacity-40 mix-blend-overlay" />
                <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/40"></div>
              </div>
              <div className="container relative z-10 px-4 md:px-8 mx-auto">
                <div className="max-w-2xl space-y-6">
                  {banner.subtitle && (
                    <span className="text-accent font-semibold tracking-widest uppercase text-sm">
                      {banner.subtitle}
                    </span>
                  )}
                  <h1 className="font-serif text-4xl md:text-6xl font-bold text-white leading-tight">
                    {banner.title}
                  </h1>
                  {banner.buttonText && (
                    <div className="pt-4">
                      <Link href={banner.buttonLink || "/books"}>
                        <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-full px-8 text-base">
                          {banner.buttonText}
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SectionSkeleton() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 mt-8">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="flex flex-col gap-3">
          <Skeleton className="aspect-[2/3] w-full rounded-xl" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      ))}
    </div>
  );
}

export function Home() {
  const { data, isLoading, isError } = useGetHomeData({
    query: {
      queryKey: getGetHomeDataQueryKey()
    }
  });

  return (
    <div className="min-h-screen pb-16">
      {isLoading ? (
        <Skeleton className="h-[60vh] w-full" />
      ) : (
        <HomeHero banners={data?.banners} />
      )}

      {/* Features strip */}
      <div className="bg-white border-b py-8">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="flex items-center gap-4 justify-center md:justify-start">
            <BookOpen className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-bold text-sm">Vast Collection</h4>
              <p className="text-xs text-muted-foreground">100,000+ premium e-books</p>
            </div>
          </div>
          <div className="flex items-center gap-4 justify-center md:justify-start">
            <Truck className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-bold text-sm">Instant Delivery</h4>
              <p className="text-xs text-muted-foreground">Download immediately</p>
            </div>
          </div>
          <div className="flex items-center gap-4 justify-center md:justify-start">
            <ShieldCheck className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-bold text-sm">Secure Payment</h4>
              <p className="text-xs text-muted-foreground">100% safe & protected</p>
            </div>
          </div>
          <div className="flex items-center gap-4 justify-center md:justify-start">
            <Clock className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-bold text-sm">24/7 Support</h4>
              <p className="text-xs text-muted-foreground">Always here to help</p>
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 mt-16 space-y-24">
        {/* Featured Section */}
        <section>
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-serif text-3xl font-bold text-foreground">Featured Picks</h2>
              <p className="text-muted-foreground mt-2">Hand-selected by our editors</p>
            </div>
            <Link href="/books">
              <Button variant="ghost" className="text-primary hover:text-primary hover:bg-primary/5 group">
                View all <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
          {isLoading ? (
            <SectionSkeleton />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {data?.featured?.slice(0, 5).map(book => (
                <BookCard key={book._id} book={book} />
              ))}
            </div>
          )}
        </section>

        {/* Category Pills */}
        <section className="bg-primary rounded-3xl p-8 md:p-12 text-center">
          <h2 className="font-serif text-3xl font-bold text-white mb-8">Browse by Genre</h2>
          <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
            {["Fiction", "Non-Fiction", "Mystery", "Sci-Fi", "Fantasy", "Biography", "Romance", "History", "Business", "Self-Help"].map((genre) => (
              <Link key={genre} href={`/books?category=${genre}`}>
                <Button variant="outline" className="rounded-full bg-white/10 text-white border-white/20 hover:bg-white hover:text-primary transition-colors">
                  {genre}
                </Button>
              </Link>
            ))}
          </div>
        </section>

        {/* Trending Section */}
        <section>
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-serif text-3xl font-bold text-foreground">Trending Now</h2>
              <p className="text-muted-foreground mt-2">What everyone is reading right now</p>
            </div>
          </div>
          {isLoading ? (
            <SectionSkeleton />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {data?.trending?.slice(0, 5).map(book => (
                <BookCard key={book._id} book={book} />
              ))}
            </div>
          )}
        </section>

        {/* Best Sellers */}
        <section className="bg-secondary p-8 md:p-12 rounded-3xl">
          <div className="flex flex-col md:flex-row items-center justify-between mb-10 text-center md:text-left gap-6">
            <div>
              <h2 className="font-serif text-3xl font-bold text-primary">Bestsellers</h2>
              <p className="text-primary/70 mt-2">Our most popular titles of all time</p>
            </div>
            <Link href="/books?bestSeller=true">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6">
                See all bestsellers
              </Button>
            </Link>
          </div>
          {isLoading ? (
            <SectionSkeleton />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {data?.bestSellers?.slice(0, 4).map(book => (
                <BookCard key={book._id} book={book} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
