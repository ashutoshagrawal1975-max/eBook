import { useGetMyOrders, getGetMyOrdersQueryKey } from "@/lib/apiClient";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, Clock, CheckCircle2, Truck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function Orders() {
  const { data, isLoading } = useGetMyOrders({
    query: { queryKey: getGetMyOrdersQueryKey() }
  });

  const orders = data?.orders || [];

  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case 'delivered':
        return <Badge className="bg-green-500 hover:bg-green-600"><CheckCircle2 className="h-3 w-3 mr-1"/> Delivered</Badge>;
      case 'processing':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-200"><Truck className="h-3 w-3 mr-1"/> Processing</Badge>;
      default:
        return <Badge variant="outline"><Clock className="h-3 w-3 mr-1"/> Pending</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
        <h1 className="font-serif text-3xl font-bold mb-8">My Orders</h1>
        <div className="space-y-6">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-48 w-full rounded-2xl" />)}
        </div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center text-center">
        <div className="h-24 w-24 bg-muted rounded-full flex items-center justify-center mb-6">
          <Package className="h-12 w-12 text-muted-foreground" />
        </div>
        <h2 className="font-serif text-3xl font-bold mb-4">No orders yet</h2>
        <p className="text-muted-foreground max-w-md mb-8">
          You haven't placed any orders yet. Discover our collection of premium e-books.
        </p>
        <Link href="/books">
          <Button size="lg" className="rounded-full px-8">Start Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-[calc(100vh-16rem)]">
      <h1 className="font-serif text-3xl md:text-4xl font-bold mb-8 text-foreground">My Orders</h1>
      
      <div className="space-y-6">
        {orders.map((order) => (
          <div key={order._id} className="bg-card border rounded-2xl overflow-hidden shadow-sm">
            <div className="bg-muted/40 p-4 sm:p-6 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="grid grid-cols-2 sm:flex gap-4 sm:gap-12">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Order Placed</p>
                  <p className="font-medium text-sm">{new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total</p>
                  <p className="font-medium text-sm text-primary">${order.totalAmount?.toFixed(2)}</p>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Order #</p>
                  <p className="font-medium text-sm">{order._id.slice(-8).toUpperCase()}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                {getStatusBadge(order.status)}
              </div>
            </div>
            
            <div className="p-4 sm:p-6 divide-y">
              {order.items?.map((item, index) => (
                <div key={index} className="py-4 first:pt-0 last:pb-0 flex gap-4">
                  <div className="w-16 sm:w-20 shrink-0 aspect-[2/3] bg-muted border rounded-md overflow-hidden">
                    {item.book?.coverImage && <img src={item.book.coverImage} alt="Cover" className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-serif font-bold text-lg">{item.book?.title || "Unknown Book"}</h4>
                    <p className="text-sm text-muted-foreground mt-1">Qty: {item.quantity}</p>
                    <p className="font-bold text-primary mt-2">${item.price?.toFixed(2)}</p>
                  </div>
                  <div className="hidden sm:flex items-center">
                    <Link href={`/books/${item.book?._id}`}>
                      <Button variant="outline" size="sm">View Book</Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
