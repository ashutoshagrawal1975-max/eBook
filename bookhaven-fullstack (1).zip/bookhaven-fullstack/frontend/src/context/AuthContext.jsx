import { createContext, useContext, useState, useEffect } from "react";
import { getProfile } from "@/lib/apiClient";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("bookhaven_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem("bookhaven_token"));
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          const res = await getProfile();
          if (res.success && res.user) {
            setUser(res.user);
            localStorage.setItem("bookhaven_user", JSON.stringify(res.user));
          } else {
            logout();
          }
        } catch (err) {
          // Keep the existing user if API fails unexpectedly, maybe token expired?
          // For now, let's keep it simple
        }
      }
      setIsLoading(false);
    };
    fetchUser();
  }, [token]);

  const login = (newToken, newUser) => {
    localStorage.setItem("bookhaven_token", newToken);
    localStorage.setItem("bookhaven_user", JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem("bookhaven_token");
    localStorage.removeItem("bookhaven_user");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!token, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
