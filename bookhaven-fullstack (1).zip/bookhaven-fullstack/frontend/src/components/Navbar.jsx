import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useGetDashboard } from "@/lib/apiClient";
import { getGetDashboardQueryKey } from "@/lib/apiClient";
import { ShoppingCart, Heart, User as UserIcon, LogOut, Menu, BookOpen, UserCircle, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const [keyword, setKeyword] = useState("");

  const { data: dashboard } = useGetDashboard({
    query: {
      enabled: isAuthenticated,
      queryKey: getGetDashboardQueryKey()
    }
  });

  const handleSearch = (e) => {
    e.preventDefault();
    if (keyword.trim()) {
      setLocation(`/search?keyword=${encodeURIComponent(keyword.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px]">
              <div className="flex flex-col gap-6 mt-6">
                <Link href="/" className="flex items-center gap-2">
                  <BookOpen className="h-6 w-6 text-primary" />
                  <span className="font-serif text-xl font-bold text-primary">BookHaven</span>
                </Link>
                <div className="flex flex-col gap-2">
                  <Link href="/books" className="text-lg py-2 border-b">Browse Books</Link>
                  <Link href="/categories" className="text-lg py-2 border-b">Categories</Link>
                  <Link href="/authors" className="text-lg py-2 border-b">Authors</Link>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <Link href="/" className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary hidden sm:block" />
            <span className="font-serif text-2xl font-bold text-primary tracking-tight">BookHaven</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 ml-6 text-sm font-medium text-muted-foreground">
            <Link href="/books" className="hover:text-primary transition-colors">Browse</Link>
            <Link href="/categories" className="hover:text-primary transition-colors">Categories</Link>
            <Link href="/authors" className="hover:text-primary transition-colors">Authors</Link>
          </nav>
        </div>

        <form onSubmit={handleSearch} className="flex-1 max-w-md hidden md:flex items-center gap-2">
          <Input 
            type="search" 
            placeholder="Search titles, authors, genres..." 
            className="w-full bg-muted border-transparent focus-visible:bg-background"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
        </form>

        <div className="flex items-center gap-2 sm:gap-4">
          {isAuthenticated ? (
            <>
              <Link href="/wishlist">
                <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-primary">
                  <Heart className="h-5 w-5" />
                  {dashboard?.wishlistCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-accent-foreground">
                      {dashboard.wishlistCount}
                    </span>
                  )}
                </Button>
              </Link>
              <Link href="/cart">
                <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-primary">
                  <ShoppingCart className="h-5 w-5" />
                  {dashboard?.cartItemsCount > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                      {dashboard.cartItemsCount}
                    </span>
                  )}
                </Button>
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.name} className="h-8 w-8 rounded-full object-cover" />
                    ) : (
                      <UserCircle className="h-6 w-6 text-muted-foreground" />
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user?.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setLocation("/profile")} className="cursor-pointer">
                    <UserIcon className="mr-2 h-4 w-4" />
                    <span>Profile & Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/orders")} className="cursor-pointer">
                    <Package className="mr-2 h-4 w-4" />
                    <span>My Orders</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-destructive cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" className="hidden sm:inline-flex">Log in</Button>
              </Link>
              <Link href="/register">
                <Button>Sign up</Button>
              </Link>
            </>
          )}
        </div>
      </div>
      <div className="p-2 md:hidden">
        <form onSubmit={handleSearch} className="flex">
          <Input 
            type="search" 
            placeholder="Search..." 
            className="w-full bg-muted border-transparent focus-visible:bg-background"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
        </form>
      </div>
    </header>
  );
}
