import { Link } from "wouter";
import { Star, ShoppingCart, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAddToCart, useAddToWishlist } from "@/lib/apiClient";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getGetDashboardQueryKey, getGetCartQueryKey, getGetWishlistQueryKey } from "@/lib/apiClient";

export function BookCard({ book }) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addToCartMutation = useAddToCart({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Added to cart",
          description: `${book.title} has been added to your cart.`,
        });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
      },
      onError: (err) => {
        toast({
          title: "Failed to add to cart",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    }
  });

  const addToWishlistMutation = useAddToWishlist({
    mutation: {
      onSuccess: () => {
        toast({
          title: "Added to wishlist",
          description: `${book.title} has been saved to your wishlist.`,
        });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
      },
      onError: (err) => {
        toast({
          title: "Failed to add to wishlist",
          description: err.message || "An error occurred.",
          variant: "destructive"
        });
      }
    }
  });

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to log in to add items to cart."
      });
      return;
    }
    addToCartMutation.mutate({ data: { bookId: book._id, quantity: 1 } });
  };

  const handleAddToWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to log in to save items to wishlist."
      });
      return;
    }
    addToWishlistMutation.mutate({ data: { bookId: book._id } });
  };

  const hasDiscount = book.discount && book.discount > 0;
  const discountedPrice = hasDiscount ? book.price * (1 - book.discount / 100) : book.price;

  return (
    <Link href={`/books/${book._id}`}>
      <div className="group relative flex flex-col h-full bg-card rounded-xl border overflow-hidden book-card-hover cursor-pointer" data-testid={`book-card-${book._id}`}>
        <div className="relative aspect-[2/3] w-full overflow-hidden bg-muted">
          <img 
            src={book.coverImage || "https://placehold.co/400x600/f8f5f0/1b2a4a?text=Book+Cover"} 
            alt={book.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
          {hasDiscount && (
            <div className="absolute top-2 left-2 bg-destructive text-destructive-foreground text-xs font-bold px-2 py-1 rounded">
              -{book.discount}%
            </div>
          )}
          
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button 
              size="icon" 
              variant="secondary" 
              className="h-8 w-8 rounded-full shadow-md bg-white hover:bg-white text-muted-foreground hover:text-destructive"
              onClick={handleAddToWishlist}
              disabled={addToWishlistMutation.isPending}
            >
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="p-4 flex flex-col flex-grow">
          <div className="mb-1 text-xs font-medium text-accent uppercase tracking-wider">
            {book.genre}
          </div>
          
          <h3 className="font-serif font-bold text-lg leading-tight mb-1 line-clamp-2 text-foreground">
            {book.title}
          </h3>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-1">
            {book.author?.name || "Unknown Author"}
          </p>
          
          <div className="mt-auto pt-2 flex items-center justify-between">
            <div className="flex flex-col">
              {hasDiscount ? (
                <>
                  <span className="text-xs text-muted-foreground line-through">${book.price.toFixed(2)}</span>
                  <span className="font-bold text-primary">${discountedPrice.toFixed(2)}</span>
                </>
              ) : (
                <span className="font-bold text-primary">${book.price.toFixed(2)}</span>
              )}
            </div>
            
            <Button 
              size="sm" 
              className="rounded-full shadow-sm bg-primary hover:bg-primary/90"
              onClick={handleAddToCart}
              disabled={addToCartMutation.isPending}
            >
              <ShoppingCart className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Add</span>
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
