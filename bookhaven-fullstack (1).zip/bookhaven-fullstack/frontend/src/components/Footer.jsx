import { Link } from "wouter";
import { BookOpen } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground border-t">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1 flex flex-col gap-4">
            <Link href="/" className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-accent" />
              <span className="font-serif text-2xl font-bold tracking-tight text-white">BookHaven</span>
            </Link>
            <p className="text-primary-foreground/70 text-sm mt-2 leading-relaxed">
              Your curated digital bookshop. Discover your next obsession with our hand-picked selection of premium e-books.
            </p>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white font-serif">Explore</h3>
            <ul className="flex flex-col gap-2 text-sm text-primary-foreground/80">
              <li><Link href="/books" className="hover:text-accent transition-colors">All Books</Link></li>
              <li><Link href="/categories" className="hover:text-accent transition-colors">Categories</Link></li>
              <li><Link href="/authors" className="hover:text-accent transition-colors">Authors</Link></li>
              <li><Link href="/books?bestSeller=true" className="hover:text-accent transition-colors">Bestsellers</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white font-serif">Support</h3>
            <ul className="flex flex-col gap-2 text-sm text-primary-foreground/80">
              <li><Link href="/faq" className="hover:text-accent transition-colors">FAQ</Link></li>
              <li><Link href="/shipping" className="hover:text-accent transition-colors">Shipping & Returns</Link></li>
              <li><Link href="/contact" className="hover:text-accent transition-colors">Contact Us</Link></li>
              <li><Link href="/privacy" className="hover:text-accent transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-white font-serif">Stay in Touch</h3>
            <p className="text-primary-foreground/70 text-sm mb-4">
              Subscribe to our newsletter for new releases and exclusive literary offers.
            </p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="px-3 py-2 bg-primary-foreground/10 border border-primary-foreground/20 rounded-md text-sm w-full focus:outline-none focus:ring-1 focus:ring-accent text-white placeholder:text-primary-foreground/50"
              />
              <button className="px-4 py-2 bg-accent text-accent-foreground font-medium rounded-md text-sm hover:bg-accent/90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-foreground/10 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-primary-foreground/60">
          <p>© {new Date().getFullYear()} BookHaven. All rights reserved.</p>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">Twitter</span>
            <span className="hover:text-white cursor-pointer">Instagram</span>
            <span className="hover:text-white cursor-pointer">Goodreads</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
