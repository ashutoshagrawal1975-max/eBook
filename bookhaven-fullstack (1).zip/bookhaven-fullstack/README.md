# BookHaven – Full Stack E-Book Store

React + Vite frontend  +  Node.js / Express / MongoDB backend.

## Quick Start

### 1. Backend
```bash
cd backend
npm install
# Edit .env — set your MONGO_URI and other secrets
npm start
```
Backend runs on http://localhost:5000

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend runs on http://localhost:5173 and calls the backend at http://localhost:5000

## Environment
- Backend `.env` is already configured for local MongoDB on port 5000
- Frontend reads `VITE_API_URL` (defaults to http://localhost:5000 if not set)
